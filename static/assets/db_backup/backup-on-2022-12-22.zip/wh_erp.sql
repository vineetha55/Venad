#
# TABLE STRUCTURE FOR: admin_login
#

DROP TABLE IF EXISTS `admin_login`;

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) DEFAULT NULL,
  `admin_password` varchar(25) NOT NULL,
  `shop_name` varchar(255) DEFAULT NULL,
  `shop_address` text,
  `user_type` varchar(10) DEFAULT NULL,
  `tin_no` varchar(255) DEFAULT NULL,
  `gstin_no` varchar(50) DEFAULT NULL,
  `phone_no` varchar(255) DEFAULT NULL,
  `emp_id` int(11) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `user_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `admin_login` (`id`, `user_name`, `admin_email`, `admin_password`, `shop_name`, `shop_address`, `user_type`, `tin_no`, `gstin_no`, `phone_no`, `emp_id`, `created_date`, `updated_date`, `user_status`) VALUES ('1', 'admin', 'marvins@gmail.com', '1234', 'TKR Residency', ' Behind Changampuzha Park Metro Station, Mamangalam, Edappally, Kochi, Kerala 682024', 'A', 'ANFG2341234', '32ARSPK8864B1ZJ', '9656905555', '0', '2017-12-11 16:23:47', '2017-12-11 11:11:44', '1');
INSERT INTO `admin_login` (`id`, `user_name`, `admin_email`, `admin_password`, `shop_name`, `shop_address`, `user_type`, `tin_no`, `gstin_no`, `phone_no`, `emp_id`, `created_date`, `updated_date`, `user_status`) VALUES ('6', 'Test', NULL, '4321', NULL, NULL, 'E', NULL, NULL, NULL, '5', '2022-12-02 00:00:00', '2022-12-02 00:00:00', '1');


#
# TABLE STRUCTURE FOR: tbl_category
#

DROP TABLE IF EXISTS `tbl_category`;

CREATE TABLE `tbl_category` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(80) NOT NULL,
  `cat_status` int(11) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_category` (`cat_id`, `cat_name`, `cat_status`) VALUES ('1', 'CURTAINS AND DRAPES', '1');
INSERT INTO `tbl_category` (`cat_id`, `cat_name`, `cat_status`) VALUES ('2', 'WALLPAPERS', '1');
INSERT INTO `tbl_category` (`cat_id`, `cat_name`, `cat_status`) VALUES ('3', 'WINDOW BLINDS', '1');
INSERT INTO `tbl_category` (`cat_id`, `cat_name`, `cat_status`) VALUES ('4', 'MOSQUITO NETS', '1');
INSERT INTO `tbl_category` (`cat_id`, `cat_name`, `cat_status`) VALUES ('5', 'SOFAS AND FURNITURES', '1');
INSERT INTO `tbl_category` (`cat_id`, `cat_name`, `cat_status`) VALUES ('6', 'ACCESSORIES', '1');


#
# TABLE STRUCTURE FOR: tbl_company_info
#

DROP TABLE IF EXISTS `tbl_company_info`;

CREATE TABLE `tbl_company_info` (
  `info_id` int(11) NOT NULL AUTO_INCREMENT,
  `info_name` varchar(50) NOT NULL,
  `info_address` varchar(100) NOT NULL,
  `info_mobile1` varchar(20) NOT NULL,
  `info_mobile2` varchar(20) NOT NULL,
  `info_email1` varchar(30) NOT NULL,
  `info_email2` varchar(30) NOT NULL,
  `info_logo` varchar(50) NOT NULL,
  `info_gstin` varchar(20) NOT NULL,
  `info_date` date NOT NULL,
  `info_status` int(11) NOT NULL,
  `info_website` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`info_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_company_info` (`info_id`, `info_name`, `info_address`, `info_mobile1`, `info_mobile2`, `info_email1`, `info_email2`, `info_logo`, `info_gstin`, `info_date`, `info_status`, `info_website`) VALUES ('1', 'ROYAL VAGA RESORTS', 'Kurisumala Road , Vazhikkadavu , Vagamon , kottayam, Kerala,685503 \r\n', '8751916916', '8749916916', 'info@royalvaga.com', 'royalvagaresort@gmail.com', 'summer-logo2.png', '32BWUPG1355F1ZM', '2022-11-24', '1', 'royalvaga.com');


#
# TABLE STRUCTURE FOR: tbl_employee
#

DROP TABLE IF EXISTS `tbl_employee`;

CREATE TABLE `tbl_employee` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(20) NOT NULL,
  `emp_fname` varchar(50) NOT NULL,
  `emp_lname` varchar(50) NOT NULL,
  `emp_dob` date NOT NULL,
  `emp_address` varchar(60) NOT NULL,
  `emp_phone` varchar(20) NOT NULL,
  `emp_phone2` varchar(20) DEFAULT NULL,
  `emp_email` varchar(30) NOT NULL,
  `emp_education` varchar(60) NOT NULL,
  `emp_idcard_type` varchar(20) NOT NULL,
  `emp_idcard_no` varchar(20) NOT NULL,
  `emp_photo` varchar(255) NOT NULL,
  `emp_joining_date` date NOT NULL,
  `emp_status` int(11) NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_employee` (`emp_id`, `employee_id`, `emp_fname`, `emp_lname`, `emp_dob`, `emp_address`, `emp_phone`, `emp_phone2`, `emp_email`, `emp_education`, `emp_idcard_type`, `emp_idcard_no`, `emp_photo`, `emp_joining_date`, `emp_status`) VALUES ('5', '5465654', 'TESTED', 'test', '2022-12-02', 'dfdfsdf', '87947684', NULL, 'asda@gnmail.com', 'asdasdads', '1', '8978435435', 'post-img1.png', '2022-12-02', '1');


#
# TABLE STRUCTURE FOR: tbl_finyear
#

DROP TABLE IF EXISTS `tbl_finyear`;

CREATE TABLE `tbl_finyear` (
  `finyear_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `fin_startdate` date NOT NULL,
  `fin_enddate` date NOT NULL,
  `fin_active` int(11) DEFAULT NULL,
  `finyear_status` int(11) NOT NULL,
  PRIMARY KEY (`finyear_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `fin_active`, `finyear_status`) VALUES ('1', '2021-2022', '2018-04-01', '2019-03-31', NULL, '0');
INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `fin_active`, `finyear_status`) VALUES ('2', '2017-2018', '2018-06-26', '2018-06-30', NULL, '0');
INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `fin_active`, `finyear_status`) VALUES ('3', '2021 - 2022', '2021-09-01', '2022-08-31', NULL, '0');
INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `fin_active`, `finyear_status`) VALUES ('4', '2022-2023', '2022-04-01', '2023-03-31', NULL, '1');


#
# TABLE STRUCTURE FOR: tbl_followup
#

DROP TABLE IF EXISTS `tbl_followup`;

CREATE TABLE `tbl_followup` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `enquiry_id` bigint(20) DEFAULT NULL,
  `enquiry_date` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `alternate` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `customer_type` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `suggested_time` datetime DEFAULT NULL,
  `lead` varchar(255) DEFAULT NULL,
  `lead_source` varchar(255) DEFAULT NULL,
  `customer_care_remarks` text,
  `enquiry_assigned_user` varchar(255) DEFAULT NULL,
  `customer_remark` text,
  `customer_status` int(11) NOT NULL,
  `approved_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_followup` (`customer_id`, `enquiry_id`, `enquiry_date`, `customername`, `mobile`, `alternate`, `email`, `customer_type`, `address`, `suggested_time`, `lead`, `lead_source`, `customer_care_remarks`, `enquiry_assigned_user`, `customer_remark`, `customer_status`, `approved_status`) VALUES ('4', '1', '2022-12-09', 'trrdd', '272572', '5725727', 'sdfsd@gg.com', 'Domestic', 'wfddsdsfsd', '0000-00-00 00:00:00', 'Social Media', 'Instagram', 'sdsdfcdsc', '5', 'sdcdscdsc', '1', '6');
INSERT INTO `tbl_followup` (`customer_id`, `enquiry_id`, `enquiry_date`, `customername`, `mobile`, `alternate`, `email`, `customer_type`, `address`, `suggested_time`, `lead`, `lead_source`, `customer_care_remarks`, `enquiry_assigned_user`, `customer_remark`, `customer_status`, `approved_status`) VALUES ('5', '2', '2022-12-22', 'Kiran', '959542425', '', '', NULL, 'Ernakulam', NULL, NULL, 'Social Media', NULL, '5', '', '1', NULL);


#
# TABLE STRUCTURE FOR: tbl_followup_call
#

DROP TABLE IF EXISTS `tbl_followup_call`;

CREATE TABLE `tbl_followup_call` (
  `fc_id` int(11) NOT NULL AUTO_INCREMENT,
  `fc_folloup_id_fk` int(11) NOT NULL,
  `fc_call_no` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fc_call_time` time DEFAULT NULL,
  `fc_call_date` date DEFAULT NULL,
  `fc_call_remark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fc_customer_status` int(11) DEFAULT NULL,
  `fc_next_call_date` date DEFAULT NULL,
  `fc_call_status` int(11) NOT NULL,
  PRIMARY KEY (`fc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `tbl_followup_call` (`fc_id`, `fc_folloup_id_fk`, `fc_call_no`, `fc_call_time`, `fc_call_date`, `fc_call_remark`, `fc_customer_status`, `fc_next_call_date`, `fc_call_status`) VALUES ('8', '4', NULL, '14:17:00', '2022-12-22', NULL, '4', '2022-12-24', '1');
INSERT INTO `tbl_followup_call` (`fc_id`, `fc_folloup_id_fk`, `fc_call_no`, `fc_call_time`, `fc_call_date`, `fc_call_remark`, `fc_customer_status`, `fc_next_call_date`, `fc_call_status`) VALUES ('9', '4', NULL, '15:24:00', '2022-12-22', NULL, '1', '2022-12-22', '1');
INSERT INTO `tbl_followup_call` (`fc_id`, `fc_folloup_id_fk`, `fc_call_no`, `fc_call_time`, `fc_call_date`, `fc_call_remark`, `fc_customer_status`, `fc_next_call_date`, `fc_call_status`) VALUES ('10', '5', NULL, '00:00:00', '2022-12-22', NULL, '5', NULL, '1');


#
# TABLE STRUCTURE FOR: tbl_hsncode
#

DROP TABLE IF EXISTS `tbl_hsncode`;

CREATE TABLE `tbl_hsncode` (
  `hsn_id` int(11) NOT NULL AUTO_INCREMENT,
  `hsncode` int(11) NOT NULL,
  `unique_hsncode` int(11) NOT NULL,
  `description` varchar(300) NOT NULL,
  `goods_service` varchar(30) NOT NULL,
  `hsn_igst` int(11) NOT NULL,
  `hsn_sgst` float NOT NULL,
  `hsn_cgst` float NOT NULL,
  `hsn_cess` int(11) NOT NULL,
  `hsn_comcess` int(11) NOT NULL,
  `hsn_flood_cess` int(11) NOT NULL,
  `hsn_project_id_fk` int(11) NOT NULL,
  `hsn_status` int(11) NOT NULL,
  PRIMARY KEY (`hsn_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_hsncode` (`hsn_id`, `hsncode`, `unique_hsncode`, `description`, `goods_service`, `hsn_igst`, `hsn_sgst`, `hsn_cgst`, `hsn_cess`, `hsn_comcess`, `hsn_flood_cess`, `hsn_project_id_fk`, `hsn_status`) VALUES ('1', '1234', '0', 'test', '', '12', '6', '6', '0', '0', '1', '0', '1');


#
# TABLE STRUCTURE FOR: tbl_product
#

DROP TABLE IF EXISTS `tbl_product`;

CREATE TABLE `tbl_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id_fk` int(11) NOT NULL,
  `subcat_id_fk` int(11) NOT NULL,
  `subcat_names` varchar(100) NOT NULL,
  `product_code` varchar(50) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_type` varchar(80) NOT NULL,
  `product_material` varchar(80) NOT NULL,
  `product_meter_price` float NOT NULL,
  `product_color` varchar(80) NOT NULL,
  `product_model` varchar(100) DEFAULT NULL,
  `product_width` double DEFAULT NULL,
  `product_height` double DEFAULT NULL,
  `product_pcs` int(11) NOT NULL,
  `product_sq_ft` double DEFAULT NULL,
  `product_unit_price` double DEFAULT NULL,
  `product_qty` int(11) DEFAULT NULL,
  `product_unit` varchar(50) NOT NULL,
  `product_total_sq_ft` double DEFAULT NULL,
  `product_price` double DEFAULT NULL,
  `product_status` int(11) NOT NULL,
  `product_photo` varchar(100) NOT NULL,
  `product_gst` int(11) NOT NULL,
  `product_hsncode` int(11) NOT NULL,
  `product_remark` mediumtext,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_product` (`product_id`, `cat_id_fk`, `subcat_id_fk`, `subcat_names`, `product_code`, `product_name`, `product_type`, `product_material`, `product_meter_price`, `product_color`, `product_model`, `product_width`, `product_height`, `product_pcs`, `product_sq_ft`, `product_unit_price`, `product_qty`, `product_unit`, `product_total_sq_ft`, `product_price`, `product_status`, `product_photo`, `product_gst`, `product_hsncode`, `product_remark`) VALUES ('1', '1', '0', '', 'SR.NO22', 'ROLEX 873', '', '', '0', '', 'Pleated', '299', '220', '6', NULL, '375', NULL, 'Meter', NULL, NULL, '1', '', '12', '83063000', 'balcony');
INSERT INTO `tbl_product` (`product_id`, `cat_id_fk`, `subcat_id_fk`, `subcat_names`, `product_code`, `product_name`, `product_type`, `product_material`, `product_meter_price`, `product_color`, `product_model`, `product_width`, `product_height`, `product_pcs`, `product_sq_ft`, `product_unit_price`, `product_qty`, `product_unit`, `product_total_sq_ft`, `product_price`, `product_status`, `product_photo`, `product_gst`, `product_hsncode`, `product_remark`) VALUES ('2', '2', '0', '', 'TEXTURE 3456-7', 'WALLPAPER', '', '', '0', '', '', NULL, NULL, '0', NULL, '3200', NULL, 'Roll', NULL, NULL, '0', '', '12', '49011010', NULL);
INSERT INTO `tbl_product` (`product_id`, `cat_id_fk`, `subcat_id_fk`, `subcat_names`, `product_code`, `product_name`, `product_type`, `product_material`, `product_meter_price`, `product_color`, `product_model`, `product_width`, `product_height`, `product_pcs`, `product_sq_ft`, `product_unit_price`, `product_qty`, `product_unit`, `product_total_sq_ft`, `product_price`, `product_status`, `product_photo`, `product_gst`, `product_hsncode`, `product_remark`) VALUES ('3', '4', '0', '', 'CODE1', 'TEST NET', '', '', '0', '', '', NULL, NULL, '0', NULL, '120', NULL, 'Sqfeet', NULL, NULL, '1', '', '12', '49011010', NULL);
INSERT INTO `tbl_product` (`product_id`, `cat_id_fk`, `subcat_id_fk`, `subcat_names`, `product_code`, `product_name`, `product_type`, `product_material`, `product_meter_price`, `product_color`, `product_model`, `product_width`, `product_height`, `product_pcs`, `product_sq_ft`, `product_unit_price`, `product_qty`, `product_unit`, `product_total_sq_ft`, `product_price`, `product_status`, `product_photo`, `product_gst`, `product_hsncode`, `product_remark`) VALUES ('4', '2', '0', '', '2455-1', 'STENNA', '', '0', '0', '', '', NULL, NULL, '0', NULL, '2500', NULL, 'Roll', NULL, NULL, '0', '', '18', '0', NULL);
INSERT INTO `tbl_product` (`product_id`, `cat_id_fk`, `subcat_id_fk`, `subcat_names`, `product_code`, `product_name`, `product_type`, `product_material`, `product_meter_price`, `product_color`, `product_model`, `product_width`, `product_height`, `product_pcs`, `product_sq_ft`, `product_unit_price`, `product_qty`, `product_unit`, `product_total_sq_ft`, `product_price`, `product_status`, `product_photo`, `product_gst`, `product_hsncode`, `product_remark`) VALUES ('5', '2', '0', '', '2455-1', 'STENNA', '', '0', '0', '', '', NULL, NULL, '0', NULL, '2500', NULL, 'Roll', NULL, NULL, '1', '', '18', '0', NULL);
INSERT INTO `tbl_product` (`product_id`, `cat_id_fk`, `subcat_id_fk`, `subcat_names`, `product_code`, `product_name`, `product_type`, `product_material`, `product_meter_price`, `product_color`, `product_model`, `product_width`, `product_height`, `product_pcs`, `product_sq_ft`, `product_unit_price`, `product_qty`, `product_unit`, `product_total_sq_ft`, `product_price`, `product_status`, `product_photo`, `product_gst`, `product_hsncode`, `product_remark`) VALUES ('6', '2', '0', '', '2455-1', 'STENNA', '', '0', '0', '', '', NULL, NULL, '0', NULL, '2500', NULL, 'Roll', NULL, NULL, '0', '', '18', '0', NULL);
INSERT INTO `tbl_product` (`product_id`, `cat_id_fk`, `subcat_id_fk`, `subcat_names`, `product_code`, `product_name`, `product_type`, `product_material`, `product_meter_price`, `product_color`, `product_model`, `product_width`, `product_height`, `product_pcs`, `product_sq_ft`, `product_unit_price`, `product_qty`, `product_unit`, `product_total_sq_ft`, `product_price`, `product_status`, `product_photo`, `product_gst`, `product_hsncode`, `product_remark`) VALUES ('7', '2', '0', '', '2455-1', 'STENNA', '', '0', '0', '', '', NULL, NULL, '0', NULL, '2500', NULL, 'Roll', NULL, NULL, '1', '', '18', '0', NULL);
INSERT INTO `tbl_product` (`product_id`, `cat_id_fk`, `subcat_id_fk`, `subcat_names`, `product_code`, `product_name`, `product_type`, `product_material`, `product_meter_price`, `product_color`, `product_model`, `product_width`, `product_height`, `product_pcs`, `product_sq_ft`, `product_unit_price`, `product_qty`, `product_unit`, `product_total_sq_ft`, `product_price`, `product_status`, `product_photo`, `product_gst`, `product_hsncode`, `product_remark`) VALUES ('8', '2', '0', '', '2455-1', 'STENNA', '', '0', '0', '', '', NULL, NULL, '0', NULL, '2500', NULL, 'Roll', NULL, NULL, '1', '', '18', '0', NULL);
INSERT INTO `tbl_product` (`product_id`, `cat_id_fk`, `subcat_id_fk`, `subcat_names`, `product_code`, `product_name`, `product_type`, `product_material`, `product_meter_price`, `product_color`, `product_model`, `product_width`, `product_height`, `product_pcs`, `product_sq_ft`, `product_unit_price`, `product_qty`, `product_unit`, `product_total_sq_ft`, `product_price`, `product_status`, `product_photo`, `product_gst`, `product_hsncode`, `product_remark`) VALUES ('9', '2', '0', '', '2455-1', 'STENNA', '', '0', '0', '', '', NULL, NULL, '0', NULL, '2500', NULL, 'Roll', NULL, NULL, '1', '', '18', '0', NULL);
INSERT INTO `tbl_product` (`product_id`, `cat_id_fk`, `subcat_id_fk`, `subcat_names`, `product_code`, `product_name`, `product_type`, `product_material`, `product_meter_price`, `product_color`, `product_model`, `product_width`, `product_height`, `product_pcs`, `product_sq_ft`, `product_unit_price`, `product_qty`, `product_unit`, `product_total_sq_ft`, `product_price`, `product_status`, `product_photo`, `product_gst`, `product_hsncode`, `product_remark`) VALUES ('10', '2', '0', '', '2455-1', 'STENNA', '', '0', '0', '', '', NULL, NULL, '0', NULL, '2500', NULL, 'Roll', NULL, NULL, '1', '', '18', '0', NULL);
INSERT INTO `tbl_product` (`product_id`, `cat_id_fk`, `subcat_id_fk`, `subcat_names`, `product_code`, `product_name`, `product_type`, `product_material`, `product_meter_price`, `product_color`, `product_model`, `product_width`, `product_height`, `product_pcs`, `product_sq_ft`, `product_unit_price`, `product_qty`, `product_unit`, `product_total_sq_ft`, `product_price`, `product_status`, `product_photo`, `product_gst`, `product_hsncode`, `product_remark`) VALUES ('11', '2', '0', '', '2455-1', 'STENNA', '', '0', '0', '', '', NULL, NULL, '0', NULL, '2500', NULL, 'Roll', NULL, NULL, '1', '', '18', '0', NULL);
INSERT INTO `tbl_product` (`product_id`, `cat_id_fk`, `subcat_id_fk`, `subcat_names`, `product_code`, `product_name`, `product_type`, `product_material`, `product_meter_price`, `product_color`, `product_model`, `product_width`, `product_height`, `product_pcs`, `product_sq_ft`, `product_unit_price`, `product_qty`, `product_unit`, `product_total_sq_ft`, `product_price`, `product_status`, `product_photo`, `product_gst`, `product_hsncode`, `product_remark`) VALUES ('12', '2', '0', '', '2455-1', 'STENNA', '', '0', '0', '', '', NULL, NULL, '0', NULL, '2500', NULL, 'Roll', NULL, NULL, '1', '', '18', '0', NULL);
INSERT INTO `tbl_product` (`product_id`, `cat_id_fk`, `subcat_id_fk`, `subcat_names`, `product_code`, `product_name`, `product_type`, `product_material`, `product_meter_price`, `product_color`, `product_model`, `product_width`, `product_height`, `product_pcs`, `product_sq_ft`, `product_unit_price`, `product_qty`, `product_unit`, `product_total_sq_ft`, `product_price`, `product_status`, `product_photo`, `product_gst`, `product_hsncode`, `product_remark`) VALUES ('13', '3', '0', '', 'SCARLET WD004', 'ZEBRA BLINDS', '', '0', '0', '', NULL, NULL, NULL, '0', NULL, '120', NULL, 'Sqfeet', NULL, NULL, '1', '', '12', '6303', NULL);
INSERT INTO `tbl_product` (`product_id`, `cat_id_fk`, `subcat_id_fk`, `subcat_names`, `product_code`, `product_name`, `product_type`, `product_material`, `product_meter_price`, `product_color`, `product_model`, `product_width`, `product_height`, `product_pcs`, `product_sq_ft`, `product_unit_price`, `product_qty`, `product_unit`, `product_total_sq_ft`, `product_price`, `product_status`, `product_photo`, `product_gst`, `product_hsncode`, `product_remark`) VALUES ('14', '6', '0', '', '12 FT', 'SS RODE', '', '', '0', '', NULL, NULL, NULL, '0', NULL, '320', NULL, 'No', NULL, NULL, '1', '', '12', '0', NULL);
INSERT INTO `tbl_product` (`product_id`, `cat_id_fk`, `subcat_id_fk`, `subcat_names`, `product_code`, `product_name`, `product_type`, `product_material`, `product_meter_price`, `product_color`, `product_model`, `product_width`, `product_height`, `product_pcs`, `product_sq_ft`, `product_unit_price`, `product_qty`, `product_unit`, `product_total_sq_ft`, `product_price`, `product_status`, `product_photo`, `product_gst`, `product_hsncode`, `product_remark`) VALUES ('15', '6', '0', '', '12 FT', 'SS RODE', '', '', '0', '', NULL, NULL, NULL, '0', NULL, '320', NULL, 'No', NULL, NULL, '1', '', '12', '0', NULL);


#
# TABLE STRUCTURE FOR: tbl_sale
#

DROP TABLE IF EXISTS `tbl_sale`;

CREATE TABLE `tbl_sale` (
  `sale_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id_fk` int(11) NOT NULL,
  `product_id_fk` int(11) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `customer_address` varchar(500) NOT NULL,
  `customer_gst` varchar(50) DEFAULT NULL,
  `customer_phone` varchar(50) DEFAULT NULL,
  `customer_email` varchar(50) DEFAULT NULL,
  `finyear` varchar(11) NOT NULL,
  `invoice_number` varchar(50) NOT NULL,
  `auto_invoice` varchar(255) NOT NULL,
  `sale_model` varchar(50) NOT NULL,
  `sale_width` float NOT NULL,
  `sale_height` float NOT NULL,
  `sale_sqfeet` float NOT NULL,
  `sale_pcs` int(11) NOT NULL,
  `sale_unit` varchar(50) NOT NULL,
  `sale_unit_price` float NOT NULL,
  `sale_qty` int(11) NOT NULL,
  `sale_total_sqfeet` float NOT NULL,
  `sale_price` float NOT NULL,
  `sale_stich_charge` float NOT NULL,
  `sale_total` float NOT NULL,
  `sale_transportation` float NOT NULL,
  `gst_status` int(11) NOT NULL,
  `gst_percent` int(11) NOT NULL,
  `gstrate` float NOT NULL,
  `sale_netamt` float NOT NULL,
  `sale_remark` varchar(100) NOT NULL,
  `sale_status` int(11) NOT NULL,
  `invoice` int(11) DEFAULT NULL,
  `sale_date` date NOT NULL,
  PRIMARY KEY (`sale_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_sale` (`sale_id`, `category_id_fk`, `product_id_fk`, `customer_name`, `customer_address`, `customer_gst`, `customer_phone`, `customer_email`, `finyear`, `invoice_number`, `auto_invoice`, `sale_model`, `sale_width`, `sale_height`, `sale_sqfeet`, `sale_pcs`, `sale_unit`, `sale_unit_price`, `sale_qty`, `sale_total_sqfeet`, `sale_price`, `sale_stich_charge`, `sale_total`, `sale_transportation`, `gst_status`, `gst_percent`, `gstrate`, `sale_netamt`, `sale_remark`, `sale_status`, `invoice`, `sale_date`) VALUES ('1', '0', '1', '4', 'wfddsdsfsd', NULL, '272572', NULL, '2022-2023', 'DL000/2022/12/1', 'MPjOosdBFe', 'Pleated', '299', '220', '0', '6', 'Meter', '375', '15', '0', '5625', '1000', '8616.6', '200', '1', '12', '1033.99', '10850.6', 'BALCONY', '1', '1', '2022-12-21');
INSERT INTO `tbl_sale` (`sale_id`, `category_id_fk`, `product_id_fk`, `customer_name`, `customer_address`, `customer_gst`, `customer_phone`, `customer_email`, `finyear`, `invoice_number`, `auto_invoice`, `sale_model`, `sale_width`, `sale_height`, `sale_sqfeet`, `sale_pcs`, `sale_unit`, `sale_unit_price`, `sale_qty`, `sale_total_sqfeet`, `sale_price`, `sale_stich_charge`, `sale_total`, `sale_transportation`, `gst_status`, `gst_percent`, `gstrate`, `sale_netamt`, `sale_remark`, `sale_status`, `invoice`, `sale_date`) VALUES ('2', '0', '3', '4', 'wfddsdsfsd', NULL, '272572', NULL, '2022-2023', 'DL000/2022/12/1', 'MPjOosdBFe', '', '173.5', '133.5', '24.93', '0', 'Sqfeet', '120', '1', '24.93', '2991.6', '1000', '8616.6', '200', '1', '12', '1033.99', '10850.6', 'WINDOW', '1', '1', '2022-12-21');


#
# TABLE STRUCTURE FOR: tbl_taxdetails
#

DROP TABLE IF EXISTS `tbl_taxdetails`;

CREATE TABLE `tbl_taxdetails` (
  `tax_id` int(11) NOT NULL AUTO_INCREMENT,
  `taxname` varchar(50) NOT NULL,
  `taxamount` double NOT NULL,
  `taxdetails` text NOT NULL,
  `tax_status` int(11) NOT NULL,
  PRIMARY KEY (`tax_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_taxdetails` (`tax_id`, `taxname`, `taxamount`, `taxdetails`, `tax_status`) VALUES ('1', 'GST 12%', '12', '12%', '1');


#
# TABLE STRUCTURE FOR: tbl_vendor
#

DROP TABLE IF EXISTS `tbl_vendor`;

CREATE TABLE `tbl_vendor` (
  `vendor_id` int(11) NOT NULL,
  `vendorname` varchar(60) NOT NULL,
  `vendoraddress` text NOT NULL,
  `vendorphone` bigint(20) NOT NULL,
  `vendoremail` varchar(50) NOT NULL,
  `vendor_oldbal` int(50) NOT NULL,
  `vendorgst` varchar(50) NOT NULL,
  `vendorstatus` int(11) NOT NULL,
  PRIMARY KEY (`vendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_vendor` (`vendor_id`, `vendorname`, `vendoraddress`, `vendorphone`, `vendoremail`, `vendor_oldbal`, `vendorgst`, `vendorstatus`) VALUES ('1', 'Jithin Steel', 'Kochi  ', '9112298988', 'jithin@qwerty.com', '120000', 'klsmfso3324jji', '0');
INSERT INTO `tbl_vendor` (`vendor_id`, `vendorname`, `vendoraddress`, `vendorphone`, `vendoremail`, `vendor_oldbal`, `vendorgst`, `vendorstatus`) VALUES ('2', 'Jithin Steel', 'Kochi  ', '9112298988', 'jithin@qwerty.com', '120000', 'klsmfso3324jji', '1');
INSERT INTO `tbl_vendor` (`vendor_id`, `vendorname`, `vendoraddress`, `vendorphone`, `vendoremail`, `vendor_oldbal`, `vendorgst`, `vendorstatus`) VALUES ('3', 'Wahy', 'Kakkanad  ', '974777', 'wahy@gmail.com', '0', 'AJUAAS2778WERF', '1');


