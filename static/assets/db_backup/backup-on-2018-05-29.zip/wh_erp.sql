#
# TABLE STRUCTURE FOR: admin_login
#

DROP TABLE IF EXISTS `admin_login`;

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_password` varchar(25) NOT NULL,
  `shop_name` varchar(255) NOT NULL,
  `shop_address` text NOT NULL,
  `user_type` varchar(10) NOT NULL,
  `tin_no` varchar(255) NOT NULL,
  `gstin_no` varchar(50) NOT NULL,
  `phone_no` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `admin_login` (`id`, `user_name`, `admin_email`, `admin_password`, `shop_name`, `shop_address`, `user_type`, `tin_no`, `gstin_no`, `phone_no`, `created_date`, `updated_date`) VALUES ('1', 'marvins', 'marvins@gmail.com', 'marvins@321', 'MARVINS-INN', 'Door No 61/4057,Electronic Street,Pallimukku Junction,Kochi-682016', 'A', 'ANFG2341234', '32ARSPK8864B1ZJ', '9656905555', '2017-12-11 16:23:47', '2017-12-11 11:11:44');


#
# TABLE STRUCTURE FOR: tbl_checkin
#

DROP TABLE IF EXISTS `tbl_checkin`;

CREATE TABLE `tbl_checkin` (
  `check_id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_id_fk` int(11) NOT NULL,
  `rev_id_fk` int(11) NOT NULL,
  `fin_year` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `street` text NOT NULL,
  `country` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `checkin_number` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `checkin_date` date NOT NULL,
  `no_of_days` varchar(20) NOT NULL,
  `no_of_person` varchar(20) NOT NULL,
  `person_plus` int(11) NOT NULL,
  `checkout_date` date NOT NULL,
  `notes` text NOT NULL,
  `rooms` varchar(50) NOT NULL,
  `room_charge` double NOT NULL,
  `additional_charge` double NOT NULL,
  `discount` double NOT NULL,
  `subtotal` double NOT NULL,
  `paidamount` double NOT NULL,
  `balance_amount` double NOT NULL,
  `cin_status` int(11) NOT NULL,
  `checkin_status` int(11) NOT NULL,
  PRIMARY KEY (`check_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('1', '1', '0', '2000-2001', 'jobymon', 'ranni', 'india', 'fdgdfg', 'Kerala', '9048048024', 'joby@gmail.com', '1', '2018-01-19', '2018-01-01', '5', '5', '1', '2018-01-31', 'gghfgh', '2', '500', '100', '10', '2700', '100', '2600', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('2', '2', '0', '2000-2001', 'vishnu', 'fgfdg', 'india', 'dfgfdg', 'Kerala', '9048048024', 'user03.wahylab@gmail.com', '2', '2018-01-19', '2018-01-01', '10', '5', '1', '2018-01-31', 'fgfg', '2', '500', '100', '10', '5400', '100', '5300', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('3', '3', '0', '2000-2001', 'Rohan', 'thodupuzha', 'india', 'thodupuzha', 'kerala', '7845296310', 'rohan@gmail.com', '3', '2018-01-22', '2018-01-23', '5', '1', '0', '2018-01-31', 'xcvv', '1', '450', '0', '10', '2025', '100', '1925', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('4', '1', '0', '2000-2001', 'jobymon', 'ranni', 'india', 'fdgdfg', 'Kerala', '9048048024', 'joby@gmail.com', '4', '2018-01-22', '2018-01-24', '7', '2', '0', '2018-01-31', 'zdxcfdsf', '2', '500', '0', '10', '3150', '100', '3050', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('5', '2', '0', '2000-2001', 'vishnu', 'fgfdg', 'india', 'dfgfdg', 'Kerala', '9048048024', 'user03.wahylab@gmail.com', '5', '2018-01-22', '2018-01-01', '10', '2', '0', '2018-01-31', 'fgfdg', '2', '500', '0', '10', '4500', '100', '4400', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('6', '4', '0', '2000-2001', 'PRAVEENKUMAR KP', 'KOTTYAM', 'India', 'xzc', 'kerala', '9961136539', 'praveenkp.etr@gmail.com', '6', '2018-04-16', '2018-04-16', '2', '2', '0', '2018-04-18', 'dsafgs', '1', '450', '0', '0', '900', '500', '400', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('7', '3', '0', '2018-2019', 'Rohan', 'thodupuzha', 'india', 'thodupuzha', 'kerala', '7845296310', 'rohan@gmail.com', '7', '2018-04-18', '2018-04-18', '5', '2', '0', '2018-04-30', 'dfgfdg', '1', '450', '0', '10', '2025', '100', '1925', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('8', '4', '0', '2018-2019', 'PRAVEENKUMAR KP', 'KOTTYAM', 'India', 'xzc', 'kerala', '9961136539', 'praveenkp.etr@gmail.com', '8', '2018-04-18', '2018-04-01', '5', '1', '0', '2018-04-30', 'fdfjn n', '2', '500', '0', '20', '2000', '100', '1900', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('9', '1', '0', '2018-2019', 'jobymon', 'ranni', 'india', 'fdgdfg', 'Kerala', '9048048024', 'joby@gmail.com', '9', '2018-04-21', '2018-04-18', '5', '1', '0', '2018-05-03', 'fdcgfdgfdg', '2', '500', '0', '10', '2250', '100', '2150', '0', '1');


#
# TABLE STRUCTURE FOR: tbl_checkout
#

DROP TABLE IF EXISTS `tbl_checkout`;

CREATE TABLE `tbl_checkout` (
  `checkout_id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id_fk` int(11) NOT NULL,
  `rev_id_fk` int(11) NOT NULL,
  `fin_year` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `guest_id_fk` int(11) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `street` text NOT NULL,
  `city` text NOT NULL,
  `country` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `checkout_number` int(11) NOT NULL,
  `checkin_date` date NOT NULL,
  `no_of_person` varchar(50) NOT NULL,
  `checkout_date` date NOT NULL,
  `notes` text NOT NULL,
  `balance_amount` double NOT NULL,
  `cout_status` int(11) NOT NULL,
  `checkout_status` int(11) NOT NULL,
  PRIMARY KEY (`checkout_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `cout_status`, `checkout_status`) VALUES ('1', '4', '0', '2000-2001', 'jobymon', '1', '9048048024', 'joby@gmail.com', 'ranni', 'fdgdfg', 'india', 'Kerala', '2018-01-22', '1', '2018-01-01', '5', '2018-01-31', 'gghfgh', '2600', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `cout_status`, `checkout_status`) VALUES ('2', '5', '0', '2000-2001', 'vishnu', '2', '9048048024', 'user03.wahylab@gmail.com', 'fgfdg', 'dfgfdg', 'india', 'Kerala', '2018-01-22', '2', '2018-01-01', '5', '2018-01-31', 'fgfg', '5300', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `cout_status`, `checkout_status`) VALUES ('3', '4', '0', '2000-2001', 'jobymon', '1', '9048048024', 'joby@gmail.com', 'ranni', 'fdgdfg', 'india', 'Kerala', '2018-01-22', '3', '2018-01-24', '2', '2018-01-31', 'zdxcfdsf', '3050', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `cout_status`, `checkout_status`) VALUES ('4', '5', '0', '2000-2001', 'vishnu', '2', '9048048024', 'user03.wahylab@gmail.com', 'fgfdg', 'dfgfdg', 'india', 'Kerala', '2018-01-23', '4', '2018-01-01', '2', '2018-01-31', 'fgfdg', '4400', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `cout_status`, `checkout_status`) VALUES ('5', '6', '0', '2000-2001', 'PRAVEENKUMAR KP', '4', '9961136539', 'praveenkp.etr@gmail.com', 'KOTTYAM', 'xzc', 'India', 'kerala', '2018-04-16', '5', '2018-04-16', '2', '2018-04-18', 'dsafgs', '400', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `cout_status`, `checkout_status`) VALUES ('6', '7', '0', '2018-2019', 'Rohan', '3', '7845296310', 'rohan@gmail.com', 'thodupuzha', 'thodupuzha', 'india', 'kerala', '2018-04-18', '6', '2018-04-18', '2', '2018-04-30', 'dfgfdg', '1925', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `cout_status`, `checkout_status`) VALUES ('7', '8', '0', '2018-2019', 'PRAVEENKUMAR KP', '4', '9961136539', 'praveenkp.etr@gmail.com', 'KOTTYAM', 'xzc', 'India', 'kerala', '2018-04-18', '7', '2018-04-01', '1', '2018-04-30', 'fdfjn n', '1900', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `cout_status`, `checkout_status`) VALUES ('8', '9', '0', '2018-2019', 'jobymon', '1', '9048048024', 'joby@gmail.com', 'ranni', 'fdgdfg', 'india', 'Kerala', '2018-04-21', '8', '2018-04-18', '1', '2018-05-03', 'fdcgfdgfdg', '2150', '1', '1');


#
# TABLE STRUCTURE FOR: tbl_finyear
#

DROP TABLE IF EXISTS `tbl_finyear`;

CREATE TABLE `tbl_finyear` (
  `finyear_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `fin_startdate` date NOT NULL,
  `fin_enddate` date NOT NULL,
  `finyear_status` int(11) NOT NULL,
  PRIMARY KEY (`finyear_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `finyear_status`) VALUES ('1', '2000-2001', '2018-01-24', '2018-01-24', '0');
INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `finyear_status`) VALUES ('2', '2017-2018', '2018-04-01', '2019-03-31', '0');
INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `finyear_status`) VALUES ('3', '2018-2019', '2018-04-01', '2019-03-31', '1');
INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `finyear_status`) VALUES ('4', '2018-2019', '2018-04-01', '2019-03-31', '1');
INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `finyear_status`) VALUES ('5', '2018-2019', '2018-04-01', '2018-05-17', '1');


#
# TABLE STRUCTURE FOR: tbl_gusetdetails
#

DROP TABLE IF EXISTS `tbl_gusetdetails`;

CREATE TABLE `tbl_gusetdetails` (
  `guest_id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_name` varchar(50) NOT NULL,
  `guest_photo` text NOT NULL,
  `arrival_date` date NOT NULL,
  `guest_street` text NOT NULL,
  `guest_city` text NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `phone_number` bigint(20) NOT NULL,
  `idcard_number` varchar(50) NOT NULL,
  `pan_number` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `guest_status` int(11) NOT NULL,
  PRIMARY KEY (`guest_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('1', 'jobymon', '23_-01.jpg', '2018-01-15', 'ranni', 'fdgdfg', 'Kerala', 'india', '9048048024', '789456123', 'CKV123456', 'joby@gmail.com', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('2', 'vishnu', 'chocolate_pie_dessert_cakes_2560x1600_wallpaper_www_animalhi_com_22.jpg', '2018-01-18', 'fgfdg', 'dfgfdg', 'Kerala', 'india', '9048048024', '789456123', '12', 'user03.wahylab@gmail.com', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('3', 'Rohan', '9bd26b59d56d65e8c76b24e8c2a868fc_featured_v2.jpg', '2018-01-22', 'thodupuzha', 'thodupuzha', 'kerala', 'india', '7845296310', '7946132589640', 'PAN784512369', 'rohan@gmail.com', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('4', 'PRAVEENKUMAR KP', 'Not uploaded', '2018-04-16', 'KOTTYAM', 'xzc', 'kerala', 'India', '9961136539', '32/254875/2002', '256482145685236695', 'praveenkp.etr@gmail.com', '1');


#
# TABLE STRUCTURE FOR: tbl_reservation
#

DROP TABLE IF EXISTS `tbl_reservation`;

CREATE TABLE `tbl_reservation` (
  `reserv_id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_id_fk` int(11) NOT NULL,
  `fin_year` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `street` text NOT NULL,
  `city` text NOT NULL,
  `country` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `checkin_date` date NOT NULL,
  `checkout_date` date NOT NULL,
  `room` int(11) NOT NULL,
  `room_charge` double NOT NULL,
  `no_of_person` int(11) NOT NULL,
  `no_of_days` int(11) NOT NULL,
  `additional_charge` double NOT NULL,
  `discount` double NOT NULL,
  `subtotal` double NOT NULL,
  `paidamount` double NOT NULL,
  `balance_amount` double NOT NULL,
  `checkout_status` int(11) NOT NULL,
  `reserv_status` int(11) NOT NULL,
  PRIMARY KEY (`reserv_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_roomdetails
#

DROP TABLE IF EXISTS `tbl_roomdetails`;

CREATE TABLE `tbl_roomdetails` (
  `room_id` int(11) NOT NULL AUTO_INCREMENT,
  `room_type` varchar(50) NOT NULL,
  `room_ac` varchar(50) NOT NULL,
  `room_number` varchar(50) NOT NULL,
  `no_of_occ` int(11) NOT NULL,
  `add_of_occ` double NOT NULL,
  `room_rate` double NOT NULL,
  `room_features` text NOT NULL,
  `room_status` int(11) NOT NULL,
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `room_status`) VALUES ('1', 'SingleRoom', 'AC', 'A0R1', '5', '500', '450', 'sdsdfdsf', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `room_status`) VALUES ('2', 'DoubleRoom', 'NonAC', 'A0R2', '4', '100', '500', 'cxfcx xcgfdhgf', '1');


#
# TABLE STRUCTURE FOR: tbl_taxdetails
#

DROP TABLE IF EXISTS `tbl_taxdetails`;

CREATE TABLE `tbl_taxdetails` (
  `tax_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_name` varchar(50) NOT NULL,
  `tax_amount` double NOT NULL,
  `tax_status` int(11) NOT NULL,
  PRIMARY KEY (`tax_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_taxdetails` (`tax_id`, `tax_name`, `tax_amount`, `tax_status`) VALUES ('1', 'GST @ 5% (split tax)', '5', '1');


#
# TABLE STRUCTURE FOR: tbl_voucherdetails
#

DROP TABLE IF EXISTS `tbl_voucherdetails`;

CREATE TABLE `tbl_voucherdetails` (
  `voucher_id` int(11) NOT NULL AUTO_INCREMENT,
  `vouch_id` int(11) NOT NULL,
  `account_head` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `narration` text NOT NULL,
  `created_date` date NOT NULL,
  `isactive` int(11) NOT NULL,
  `fin_year` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `voucher_status` int(11) NOT NULL,
  PRIMARY KEY (`voucher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('1', '100', 'Current Bill', '150', ' gdfgfdhfgjgjk', '2018-01-30', '1', '2000-2001', '1', 'voucher', '1');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('2', '101', 'sadafsdf', '800', ' dsfdsfsdf', '2018-02-01', '1', '2000-2001', '1', 'voucher', '1');


#
# TABLE STRUCTURE FOR: tbl_voucherentry
#

DROP TABLE IF EXISTS `tbl_voucherentry`;

CREATE TABLE `tbl_voucherentry` (
  `entry_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `entry_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `voucher_head` int(11) NOT NULL,
  `voucherid` int(11) NOT NULL,
  `entry_amount` double NOT NULL,
  `paidto` varchar(50) NOT NULL,
  `entry_narration` text NOT NULL,
  `entry_status` int(11) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('1', '2000-2001', '2018-01-23', '1', '1', '100', '150', 'cxcxc', 'zxcxzc', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('2', '2000-2001', '2018-01-23', '1', '2', '101', '800', 'dfdsf', 'sdfsdf', '1');


