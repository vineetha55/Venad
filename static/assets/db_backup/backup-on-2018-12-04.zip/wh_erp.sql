#
# TABLE STRUCTURE FOR: admin_login
#

DROP TABLE IF EXISTS `admin_login`;

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_password` varchar(25) NOT NULL,
  `shop_name` varchar(255) NOT NULL,
  `shop_address` text NOT NULL,
  `user_type` varchar(10) NOT NULL,
  `tin_no` varchar(255) NOT NULL,
  `gstin_no` varchar(50) NOT NULL,
  `phone_no` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  `user_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `admin_login` (`id`, `user_name`, `admin_email`, `admin_password`, `shop_name`, `shop_address`, `user_type`, `tin_no`, `gstin_no`, `phone_no`, `created_date`, `updated_date`, `user_status`) VALUES ('1', 'admin', 'marvins@gmail.com', 'admin', 'TKR Residency', ' Behind Changampuzha Park Metro Station, Mamangalam, Edappally, Kochi, Kerala 682024', 'A', 'ANFG2341234', '32ARSPK8864B1ZJ', '9656905555', '2017-12-11 16:23:47', '2017-12-11 11:11:44', '0');
INSERT INTO `admin_login` (`id`, `user_name`, `admin_email`, `admin_password`, `shop_name`, `shop_address`, `user_type`, `tin_no`, `gstin_no`, `phone_no`, `created_date`, `updated_date`, `user_status`) VALUES ('2', 'Maiz', '', '123456', '', '', 'user', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0');


#
# TABLE STRUCTURE FOR: tbl_checkin
#

DROP TABLE IF EXISTS `tbl_checkin`;

CREATE TABLE `tbl_checkin` (
  `check_id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_id_fk` int(11) NOT NULL,
  `rev_id_fk` int(11) NOT NULL,
  `fin_year` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `street` text NOT NULL,
  `country` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `checkin_number` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `checkin_date` date NOT NULL,
  `no_of_days` varchar(20) NOT NULL,
  `no_of_person` varchar(20) NOT NULL,
  `person_plus` int(11) NOT NULL,
  `checkout_date` date NOT NULL,
  `notes` text NOT NULL,
  `rooms` varchar(50) NOT NULL,
  `room_charge` double NOT NULL,
  `additional_charge` double NOT NULL,
  `discount` double NOT NULL,
  `subtotal` double NOT NULL,
  `paidamount` double NOT NULL,
  `balance_amount` double NOT NULL,
  `cin_status` int(11) NOT NULL,
  `checkin_status` int(11) NOT NULL,
  PRIMARY KEY (`check_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_checkout
#

DROP TABLE IF EXISTS `tbl_checkout`;

CREATE TABLE `tbl_checkout` (
  `checkout_id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id_fk` int(11) NOT NULL,
  `rev_id_fk` int(11) NOT NULL,
  `fin_year` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `guest_id_fk` int(11) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `street` text NOT NULL,
  `city` text NOT NULL,
  `country` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `checkout_number` int(11) NOT NULL,
  `checkin_date` date NOT NULL,
  `no_of_person` varchar(50) NOT NULL,
  `checkout_date` date NOT NULL,
  `notes` text NOT NULL,
  `balance_amount` double NOT NULL,
  `payment_mode` varchar(50) NOT NULL,
  `cout_status` int(11) NOT NULL,
  `checkout_status` int(11) NOT NULL,
  PRIMARY KEY (`checkout_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_daybook
#

DROP TABLE IF EXISTS `tbl_daybook`;

CREATE TABLE `tbl_daybook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `closing_amount` double NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_finyear
#

DROP TABLE IF EXISTS `tbl_finyear`;

CREATE TABLE `tbl_finyear` (
  `finyear_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `fin_startdate` date NOT NULL,
  `fin_enddate` date NOT NULL,
  `finyear_status` int(11) NOT NULL,
  PRIMARY KEY (`finyear_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `finyear_status`) VALUES ('1', '2018-2019', '2018-04-01', '2019-03-31', '1');
INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `finyear_status`) VALUES ('2', '2017-2018', '2018-06-26', '2018-06-30', '0');


#
# TABLE STRUCTURE FOR: tbl_gusetdetails
#

DROP TABLE IF EXISTS `tbl_gusetdetails`;

CREATE TABLE `tbl_gusetdetails` (
  `guest_id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_name` varchar(50) NOT NULL,
  `guest_photo` text NOT NULL,
  `arrival_date` date NOT NULL,
  `guest_street` text NOT NULL,
  `guest_city` text NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `phone_number` bigint(20) NOT NULL,
  `idcard_number` varchar(50) NOT NULL,
  `pan_number` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `guest_status` int(11) NOT NULL,
  PRIMARY KEY (`guest_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('1', 'jobymon', '23_-01.jpg', '2018-01-15', 'ranni', 'fdgdfg', 'Kerala', 'india', '9048048024', '789456123', 'CKV123456', 'joby@gmail.com', '0');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('2', 'vishnu', 'marina.jpg', '2018-06-11', 'fgfdg', 'dfgfdg', 'Kerala', 'india', '9048048024', '789456123', '12', 'user03.wahylab@gmail.com', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('3', 'Rohan', '9bd26b59d56d65e8c76b24e8c2a868fc_featured_v2.jpg', '2018-01-22', 'thodupuzha', 'thodupuzha', 'kerala', 'india', '7845296310', '7946132589640', 'PAN784512369', 'rohan@gmail.com', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('4', 'PRAVEENKUMAR KP', 'Not uploaded', '2018-04-16', 'KOTTYAM', 'xzc', 'kerala', 'India', '9961136539', '32/254875/2002', '256482145685236695', 'praveenkp.etr@gmail.com', '0');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('5', 'anand', 'sample.png', '2018-06-13', 'htl', 'ekm', 'kerala', 'india', '9788675467', 'in35468', 'a567d45', 'aaa@s.n', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('6', 'deepak', 'deepak.jpg', '2018-06-18', 'kochi', 'kochi', 'kerala', 'india', '9048048024', '123', '12', 'd@d.com', '1');


#
# TABLE STRUCTURE FOR: tbl_receiptdetails
#

DROP TABLE IF EXISTS `tbl_receiptdetails`;

CREATE TABLE `tbl_receiptdetails` (
  `receipt_id` int(20) NOT NULL AUTO_INCREMENT,
  `rec_id` int(20) NOT NULL,
  `account_head` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `narration` varchar(300) NOT NULL,
  `fin_year` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `isactive` varchar(50) NOT NULL,
  `receipt_status` int(20) NOT NULL,
  PRIMARY KEY (`receipt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_receiptdetails` (`receipt_id`, `rec_id`, `account_head`, `amount`, `narration`, `fin_year`, `user_id`, `type`, `created_date`, `isactive`, `receipt_status`) VALUES ('1', '100', 'hi', '1200', ' hello', '2018-2019', '1', 'receipt', '2018-06-28', '1', '1');
INSERT INTO `tbl_receiptdetails` (`receipt_id`, `rec_id`, `account_head`, `amount`, `narration`, `fin_year`, `user_id`, `type`, `created_date`, `isactive`, `receipt_status`) VALUES ('3', '101', 'Sam\'s bill', '10000', ' ', '2018-2019', '1', 'receipt', '2018-06-26', '1', '1');


#
# TABLE STRUCTURE FOR: tbl_receiptentry
#

DROP TABLE IF EXISTS `tbl_receiptentry`;

CREATE TABLE `tbl_receiptentry` (
  `entry_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `entry_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `receipt_head` int(11) NOT NULL,
  `receiptid` int(11) NOT NULL,
  `entry_amount` double NOT NULL,
  `paidto` varchar(50) NOT NULL,
  `entry_narration` text NOT NULL,
  `entry_status` int(11) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_receiptentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `receipt_head`, `receiptid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('1', '2018-2019', '2018-06-28', '1', '1', '100', '1200', 'sim', ' ', '1');
INSERT INTO `tbl_receiptentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `receipt_head`, `receiptid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('2', '2018-2019', '2018-06-28', '1', '3', '101', '10000', 'dasdasd', ' sadsad', '1');
INSERT INTO `tbl_receiptentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `receipt_head`, `receiptid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('3', '2018-2019', '2018-06-28', '1', '3', '101', '10000', 'dfs', ' ', '1');


#
# TABLE STRUCTURE FOR: tbl_reservation
#

DROP TABLE IF EXISTS `tbl_reservation`;

CREATE TABLE `tbl_reservation` (
  `reserv_id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_id_fk` int(11) NOT NULL,
  `fin_year` varchar(20) NOT NULL,
  `created_date` date NOT NULL,
  `name` varchar(20) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `street` text NOT NULL,
  `city` text NOT NULL,
  `country` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `checkin_date` date NOT NULL,
  `checkout_date` date NOT NULL,
  `room` int(11) NOT NULL,
  `room_charge` double NOT NULL,
  `no_of_person` int(11) NOT NULL,
  `no_of_days` int(11) NOT NULL,
  `additional_charge` double NOT NULL,
  `discount` double NOT NULL,
  `subtotal` double NOT NULL,
  `paidamount` double NOT NULL,
  `balance_amount` double NOT NULL,
  `checkout_status` int(11) NOT NULL,
  `reserv_status` int(11) NOT NULL,
  PRIMARY KEY (`reserv_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_roomdetails
#

DROP TABLE IF EXISTS `tbl_roomdetails`;

CREATE TABLE `tbl_roomdetails` (
  `room_id` int(11) NOT NULL AUTO_INCREMENT,
  `room_type` varchar(50) NOT NULL,
  `room_ac` varchar(50) NOT NULL,
  `room_number` varchar(50) NOT NULL,
  `no_of_occ` int(11) NOT NULL,
  `add_of_occ` double NOT NULL,
  `room_rate` double NOT NULL,
  `room_features` text NOT NULL,
  `occupied` int(11) NOT NULL DEFAULT '0',
  `room_active` int(11) NOT NULL,
  `room_status` int(11) NOT NULL,
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('1', '1', 'AC', '202', '2', '300', '1200', 'dsfdsfdsf', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('2', '2', 'AC', '202', '2', '300', '1200', 'sdfdsfds', '0', '0', '1');


#
# TABLE STRUCTURE FOR: tbl_roommaster
#

DROP TABLE IF EXISTS `tbl_roommaster`;

CREATE TABLE `tbl_roommaster` (
  `masterid` int(11) NOT NULL AUTO_INCREMENT,
  `mastername` varchar(250) NOT NULL,
  `masterdescription` text NOT NULL,
  `masterstatus` int(11) NOT NULL,
  PRIMARY KEY (`masterid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_roommaster` (`masterid`, `mastername`, `masterdescription`, `masterstatus`) VALUES ('1', 'Standard Rooms', 'dsfdsfdsf', '1');
INSERT INTO `tbl_roommaster` (`masterid`, `mastername`, `masterdescription`, `masterstatus`) VALUES ('2', 'Deluxe Rooms', 'sdfdsfds', '1');
INSERT INTO `tbl_roommaster` (`masterid`, `mastername`, `masterdescription`, `masterstatus`) VALUES ('3', 'Double Room With Kitchen', '2 Bed  And Kitchen', '1');


#
# TABLE STRUCTURE FOR: tbl_taxdetails
#

DROP TABLE IF EXISTS `tbl_taxdetails`;

CREATE TABLE `tbl_taxdetails` (
  `tax_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_name` varchar(50) NOT NULL,
  `tax_amount` double NOT NULL,
  `cgst` double NOT NULL,
  `sgst` double NOT NULL,
  `igst` double NOT NULL,
  `tax_status` int(11) NOT NULL,
  PRIMARY KEY (`tax_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_taxdetails` (`tax_id`, `tax_name`, `tax_amount`, `cgst`, `sgst`, `igst`, `tax_status`) VALUES ('1', 'Tax1', '18', '9', '9', '18', '1');
INSERT INTO `tbl_taxdetails` (`tax_id`, `tax_name`, `tax_amount`, `cgst`, `sgst`, `igst`, `tax_status`) VALUES ('2', '4jfgj', '50', '25', '25', '50', '1');


#
# TABLE STRUCTURE FOR: tbl_voucherdetails
#

DROP TABLE IF EXISTS `tbl_voucherdetails`;

CREATE TABLE `tbl_voucherdetails` (
  `voucher_id` int(11) NOT NULL AUTO_INCREMENT,
  `vouch_id` int(11) NOT NULL,
  `account_head` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `narration` text NOT NULL,
  `created_date` date NOT NULL,
  `isactive` int(11) NOT NULL,
  `fin_year` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `voucher_status` int(11) NOT NULL,
  PRIMARY KEY (`voucher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('1', '100', 'AC BILL', '1200', ' ', '2018-06-29', '1', '2018-2019', '1', 'voucher', '1');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('2', '101', 'Consultancy fee', '2000', '  pay', '2018-11-15', '1', '2018-2019', '1', 'voucher', '1');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('3', '102', 'ann\'s bill', '5000', ' ', '2018-07-05', '0', '2018-2019', '1', 'voucher', '1');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('4', '103', 'promotion fee', '3000', ' ', '2018-06-20', '0', '2018-2019', '1', 'voucher', '1');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('5', '104', 'tv ads', '5000', ' ', '2018-06-30', '0', '2018-2019', '1', 'voucher', '1');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('6', '105', 'food supply payment', '4000', ' ', '2018-07-11', '0', '2018-2019', '1', 'voucher', '0');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('7', '105', 'dszfvdsffgdsfgdgdf  bdfghdfgh', '400', ' xzcfddsfdsf', '2018-07-20', '0', '2018-2019', '1', 'voucher', '1');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('8', '106', 'qwerty', '1200', ' vffdchfcfhgv', '2018-11-22', '0', '2018-2019', '1', 'voucher', '1');


#
# TABLE STRUCTURE FOR: tbl_voucherentry
#

DROP TABLE IF EXISTS `tbl_voucherentry`;

CREATE TABLE `tbl_voucherentry` (
  `entry_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `entry_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `voucher_head` int(11) NOT NULL,
  `voucherid` int(11) NOT NULL,
  `entry_amount` double NOT NULL,
  `paidto` varchar(50) NOT NULL,
  `entry_narration` text NOT NULL,
  `entry_status` int(11) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('1', '2018-2019', '2018-06-28', '1', '1', '100', '1200', 'smith', ' ', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('2', '2018-2019', '2018-06-27', '1', '2', '101', '2000', 'sim', ' ', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('3', '2018-2019', '2018-06-27', '1', '4', '103', '3000', 'wahylab', ' ', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('4', '2018-2019', '2018-08-22', '1', '5', '104', '5000', 'surya tv', ' ', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('5', '2018-2019', '2018-07-25', '1', '6', '105', '4000', 'sasi\'s mess', ' ', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('6', '2018-2019', '2018-07-11', '1', '5', '104', '10000', 'asianet', ' ', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('7', '2018-2019', '2018-07-11', '1', '6', '105', '7000', 'pi dosa', ' ', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('8', '2018-2019', '2018-06-28', '1', '1', '100', '1200', 'dasdasd', ' dsaf', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('9', '2018-2019', '2018-06-25', '1', '1', '100', '1200', 'qwerty', ' sdfg', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('10', '2018-2019', '2018-06-25', '1', '2', '101', '2000', 'sadasd', ' sadsad', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('11', '2018-2019', '2018-10-24', '1', '1', '100', '1200', 'fsgdfhsfkgjfdgk;lh;jghk', ' sdsadasdsad', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('12', '2018-2019', '2018-11-28', '1', '8', '106', '1200', 'fsgdfhsfkgjfdgk;lh;jghk', ' xfgdfdhygt', '1');


