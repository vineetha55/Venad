#
# TABLE STRUCTURE FOR: admin_login
#

DROP TABLE IF EXISTS `admin_login`;

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_password` varchar(25) NOT NULL,
  `shop_name` varchar(255) NOT NULL,
  `shop_address` text NOT NULL,
  `user_type` varchar(10) NOT NULL,
  `tin_no` varchar(255) NOT NULL,
  `gstin_no` varchar(50) NOT NULL,
  `phone_no` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  `user_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `admin_login` (`id`, `user_name`, `admin_email`, `admin_password`, `shop_name`, `shop_address`, `user_type`, `tin_no`, `gstin_no`, `phone_no`, `created_date`, `updated_date`, `user_status`) VALUES ('1', 'admin', 'marvins@gmail.com', 'admin', 'TKR Residency', ' Behind Changampuzha Park Metro Station, Mamangalam, Edappally, Kochi, Kerala 682024', 'A', 'ANFG2341234', '32ARSPK8864B1ZJ', '9656905555', '2017-12-11 16:23:47', '2017-12-11 11:11:44', '0');
INSERT INTO `admin_login` (`id`, `user_name`, `admin_email`, `admin_password`, `shop_name`, `shop_address`, `user_type`, `tin_no`, `gstin_no`, `phone_no`, `created_date`, `updated_date`, `user_status`) VALUES ('2', 'Maiz', '', '123456', '', '', 'user', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0');


#
# TABLE STRUCTURE FOR: tbl_checkin
#

DROP TABLE IF EXISTS `tbl_checkin`;

CREATE TABLE `tbl_checkin` (
  `check_id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_id_fk` int(11) NOT NULL,
  `rev_id_fk` int(11) NOT NULL,
  `fin_year` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `street` text NOT NULL,
  `country` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `checkin_number` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `checkin_date` date NOT NULL,
  `no_of_days` varchar(20) NOT NULL,
  `no_of_person` varchar(20) NOT NULL,
  `person_plus` int(11) NOT NULL,
  `checkout_date` date NOT NULL,
  `notes` text NOT NULL,
  `rooms` varchar(50) NOT NULL,
  `room_charge` double NOT NULL,
  `additional_charge` double NOT NULL,
  `discount` double NOT NULL,
  `subtotal` double NOT NULL,
  `paidamount` double NOT NULL,
  `balance_amount` double NOT NULL,
  `cin_status` int(11) NOT NULL,
  `checkin_status` int(11) NOT NULL,
  PRIMARY KEY (`check_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('1', '0', '0', '2018-2019', 'sumi', 'ljxkh', 'india', 'tcr', 'kerala', '8592818946', 'sumi@yahoo.com', '1', '2018-05-30', '2018-05-30', '2', '1', '2', '2018-06-02', 'mnbdcmn', '2', '500', '0', '10', '900', '200', '700', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('2', '0', '0', '2018-2019', 'sam', 'Magalium Temple', 'india', 'kochi', 'kerala', '987654321', 'd@d.com', '2', '2018-06-07', '2018-06-11', '39', '4', '0', '2018-07-20', '', '2', '500', '0', '11', '19500', '10000', '9500', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('3', '2', '0', '2018-2019', 'vishnu', 'fgfdg', 'india', 'dfgfdg', 'Kerala', '9048048024', 'user03.wahylab@gmail.com', '3', '2018-06-07', '2018-07-11', '17', '4', '0', '2018-07-28', '', '2', '500', '0', '11', '8500', '6000', '2500', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('4', '3', '0', '2018-2019', 'Rohan', 'thodupuzha', 'india', 'thodupuzha', 'kerala', '7845296310', 'rohan@gmail.com', '4', '2018-06-07', '2018-06-14', '27', '4', '0', '2018-07-11', '', '2', '500', '0', '11', '13500', '10000', '3500', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('5', '0', '0', '2018-2019', 'aleena', 'Magalium Temple', 'india', 'kochi', 'kerala', '987654321', 'd@d.com', '5', '2018-06-08', '2018-06-12', '45', '4', '1', '2018-07-27', '', '1', '500', '100', '11', '27000', '10000', '17000', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('6', '2', '0', '2017-2018', 'vishnu', 'fgfdg', 'india', 'dfgfdg', 'Kerala', '9048048024', 'user03.wahylab@gmail.com', '6', '2018-06-18', '2018-06-05', '51', '4', '1', '2018-07-26', '', '1', '500', '100', '11', '30600', '10000', '20600', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('7', '2', '0', '2018-2019', 'vishnu', 'fgfdg', 'india', 'dfgfdg', 'Kerala', '9048048024', 'user03.wahylab@gmail.com', '7', '2018-06-18', '2018-07-11', '16', '4', '2', '2018-07-27', '', '3', '2000', '400', '11', '38400', '10000', '28400', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('8', '2', '0', '2018-2019', 'vishnu', 'fgfdg', 'india', 'dfgfdg', 'Kerala', '9048048024', 'user03.wahylab@gmail.com', '8', '2018-06-25', '2018-06-25', '3', '5', '3', '2018-06-28', 'rfgt', '5', '1200', '1200', '0', '7200', '100', '7100', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('9', '3', '0', '2018-2019', 'Rohan', 'thodupuzha', 'india', 'thodupuzha', 'kerala', '7845296310', 'rohan@gmail.com', '9', '2018-06-25', '2018-06-25', '2', '1', '0', '2018-06-27', 'sd', '3', '2000', '0', '0', '4000', '100', '3900', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('10', '5', '0', '2018-2019', 'anand', 'htl', 'india', 'ekm', 'kerala', '9788675467', 'aaa@s.n', '10', '2018-06-28', '2018-06-07', '15', '10', '9', '2018-06-22', '1010', '6', '200', '4500', '0', '70500', '100', '70400', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('11', '5', '1', '2018-2019', 'anand', 'htl', 'india', 'ekm', 'kerala', '9788675467', 'aaa@s.n', '10', '2018-06-28', '2018-06-07', '49', '6', '4', '2018-07-26', 'dxfcd', '7', '500', '4', '1', '24696', '100', '24596', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('12', '0', '0', '2018-2019', 'Ramiz o', 'malappuram', 'india', 'kottakkal', 'kerala', '9526989842', 'erfa', '10', '2018-10-31', '2018-10-16', '5', '5', '0', '2018-11-21', 'jdaijd', '', '1200', '10', '0', '6050', '500', '-500', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('13', '0', '0', '2018-2019', 'RAMIZ', 'KOTTAKKAL', 'INDIA', 'RANDATHANI', 'KERALA', '9526989842', 'ramisodayappurath@gmail.com', '10', '2018-10-31', '2018-10-23', '1', '2', '1', '2018-10-24', 'NO', '6', '200', '0', '0', '200', '500', '-300', '0', '1');
INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('14', '2', '0', '2018-2019', 'vishnu', 'fgfdg', 'india', 'dfgfdg', 'Kerala', '9048048024', 'user03.wahylab@gmail.com', '10', '2018-11-09', '2018-11-08', '15', '4', '2', '2018-11-23', 'ddgfhdhfgd gfjgfj', '5', '1200', '800', '5', '30000', '1000', '29000', '0', '1');


#
# TABLE STRUCTURE FOR: tbl_checkout
#

DROP TABLE IF EXISTS `tbl_checkout`;

CREATE TABLE `tbl_checkout` (
  `checkout_id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id_fk` int(11) NOT NULL,
  `rev_id_fk` int(11) NOT NULL,
  `fin_year` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `guest_id_fk` int(11) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `street` text NOT NULL,
  `city` text NOT NULL,
  `country` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `checkout_number` int(11) NOT NULL,
  `checkin_date` date NOT NULL,
  `no_of_person` varchar(50) NOT NULL,
  `checkout_date` date NOT NULL,
  `notes` text NOT NULL,
  `balance_amount` double NOT NULL,
  `payment_mode` varchar(50) NOT NULL,
  `cout_status` int(11) NOT NULL,
  `checkout_status` int(11) NOT NULL,
  PRIMARY KEY (`checkout_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('1', '4', '0', '2000-2001', 'jobymon', '1', '9048048024', 'joby@gmail.com', 'ranni', 'fdgdfg', 'india', 'Kerala', '2018-01-22', '1', '2018-01-01', '5', '2018-01-31', 'gghfgh', '2600', '', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('2', '5', '0', '2000-2001', 'vishnu', '2', '9048048024', 'user03.wahylab@gmail.com', 'fgfdg', 'dfgfdg', 'india', 'Kerala', '2018-01-22', '2', '2018-01-01', '5', '2018-01-31', 'fgfg', '5300', '', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('3', '4', '0', '2000-2001', 'jobymon', '1', '9048048024', 'joby@gmail.com', 'ranni', 'fdgdfg', 'india', 'Kerala', '2018-01-22', '3', '2018-01-24', '2', '2018-01-31', 'zdxcfdsf', '3050', '', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('4', '5', '0', '2000-2001', 'vishnu', '2', '9048048024', 'user03.wahylab@gmail.com', 'fgfdg', 'dfgfdg', 'india', 'Kerala', '2018-01-23', '4', '2018-01-01', '2', '2018-01-31', 'fgfdg', '4400', '', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('5', '6', '0', '2000-2001', 'PRAVEENKUMAR KP', '4', '9961136539', 'praveenkp.etr@gmail.com', 'KOTTYAM', 'xzc', 'India', 'kerala', '2018-04-16', '5', '2018-04-16', '2', '2018-04-18', 'dsafgs', '400', '', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('6', '7', '0', '2018-2019', 'Rohan', '3', '7845296310', 'rohan@gmail.com', 'thodupuzha', 'thodupuzha', 'india', 'kerala', '2018-04-18', '6', '2018-04-18', '2', '2018-04-30', 'dfgfdg', '1925', '', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('7', '8', '0', '2018-2019', 'PRAVEENKUMAR KP', '4', '9961136539', 'praveenkp.etr@gmail.com', 'KOTTYAM', 'xzc', 'India', 'kerala', '2018-04-18', '7', '2018-04-01', '1', '2018-04-30', 'fdfjn n', '1900', '', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('8', '9', '0', '2018-2019', 'jobymon', '1', '9048048024', 'joby@gmail.com', 'ranni', 'fdgdfg', 'india', 'Kerala', '2018-04-21', '8', '2018-04-18', '1', '2018-05-03', 'fdcgfdgfdg', '2150', '', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('9', '10', '0', '2018-2019', 'varsha', '0', '9744629654', 'varsha@gmail.com', 'ljxkh', 'tcr', 'india', 'kerala', '2018-05-29', '9', '2018-05-31', '2', '2018-07-02', 'jvf', '800', '', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('10', '11', '0', '2018-2019', 'anand', '0', '9877656787', 'aaa@s.n', 'htl', 'ekm', 'india', 'kerala', '2018-05-29', '10', '2018-05-29', '4', '2018-05-31', 'kjhj', '900', '', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('11', '12', '0', '2018-2019', 'sana', '3', '7845296310', 'sana@gmail.com', 'thodupuzha', 'thodupuzha', 'india', 'kerala', '2018-05-29', '11', '2018-05-11', '4', '2018-05-31', 'fd', '2686', '', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('12', '2', '0', '2018-2019', 'sam', '0', '987654321', 'd@d.com', 'Magalium Temple', 'kochi', 'india', 'kerala', '2018-06-07', '12', '2018-05-30', '1', '2018-06-02', 'mnbdcmn', '700', '', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('13', '2', '0', '2018-2019', 'sam', '0', '987654321', 'd@d.com', 'Magalium Temple', 'kochi', 'india', 'kerala', '2018-06-07', '13', '2018-06-11', '4', '2018-07-20', '', '9500', '', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('14', '3', '0', '2018-2019', 'vishnu', '2', '9048048024', 'user03.wahylab@gmail.com', 'fgfdg', 'dfgfdg', 'india', 'Kerala', '2018-06-07', '14', '2018-07-11', '4', '2018-07-28', '', '2500', '', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('15', '4', '0', '2018-2019', 'Rohan', '3', '7845296310', 'rohan@gmail.com', 'thodupuzha', 'thodupuzha', 'india', 'kerala', '2018-06-07', '15', '2018-06-14', '4', '2018-07-11', '', '3500', '', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('16', '4', '0', '2018-2019', 'Rohan', '3', '7845296310', 'rohan@gmail.com', 'thodupuzha', 'thodupuzha', 'india', 'kerala', '2018-06-07', '16', '2018-06-14', '4', '2018-07-11', '', '3500', '', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('17', '5', '0', '2018-2019', 'aleena', '0', '987654321', 'd@d.com', 'Magalium Temple', 'kochi', 'india', 'kerala', '2018-06-12', '17', '2018-06-12', '4', '2018-07-27', '', '17000', 'card', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('18', '6', '0', '2017-2018', 'vishnu', '2', '9048048024', 'user03.wahylab@gmail.com', 'fgfdg', 'dfgfdg', 'india', 'Kerala', '2018-06-18', '18', '2018-06-05', '4', '2018-07-26', '', '20600', 'card', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('19', '7', '0', '2018-2019', 'vishnu', '2', '9048048024', 'user03.wahylab@gmail.com', 'fgfdg', 'dfgfdg', 'india', 'Kerala', '2018-06-25', '19', '2018-07-11', '4', '2018-07-27', 'gh', '28400', 'card', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('20', '9', '0', '2018-2019', 'Rohan', '3', '7845296310', 'rohan@gmail.com', 'thodupuzha', 'thodupuzha', 'india', 'kerala', '2018-06-25', '20', '2018-06-25', '1', '2018-06-27', 'sd', '3900', 'cash', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('21', '8', '0', '2018-2019', 'vishnu', '2', '9048048024', 'user03.wahylab@gmail.com', 'fgfdg', 'dfgfdg', 'india', 'Kerala', '2018-06-28', '21', '2018-06-25', '5', '2018-06-28', 'rfgt', '7100', 'card', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('22', '10', '0', '2018-2019', 'anand', '5', '9788675467', 'aaa@s.n', 'htl', 'ekm', 'india', 'kerala', '2018-10-12', '22', '2018-10-10', '10', '2018-06-22', '1010', '70400', 'cash', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('23', '11', '1', '2018-2019', 'anand', '5', '9788675467', 'aaa@s.n', 'htl', 'ekm', 'india', 'kerala', '2018-10-31', '23', '2018-06-07', '6', '2018-07-26', 'dxfcd', '24596', 'cash', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('24', '13', '0', '2018-2019', 'RAMIZ', '0', '9526989842', 'ramisodayappurath@gmail.com', 'KOTTAKKAL', 'RANDATHANI', 'INDIA', 'KERALA', '2018-10-31', '24', '2018-10-16', '5', '2018-11-21', 'jdaijd', '-500', 'Please select', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('25', '13', '0', '2018-2019', 'RAMIZ', '0', '9526989842', 'ramisodayappurath@gmail.com', 'KOTTAKKAL', 'RANDATHANI', 'INDIA', 'KERALA', '2018-10-31', '25', '2018-10-23', '2', '2018-10-24', 'NO', '-300', 'cash', '1', '1');
INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('26', '14', '0', '2018-2019', 'vishnu', '2', '9048048024', 'user03.wahylab@gmail.com', 'fgfdg', 'dfgfdg', 'india', 'Kerala', '2018-11-09', '26', '2018-11-08', '4', '2018-11-23', 'ddgfhdhfgd gfjgfj', '29000', 'cash', '1', '1');


#
# TABLE STRUCTURE FOR: tbl_daybook
#

DROP TABLE IF EXISTS `tbl_daybook`;

CREATE TABLE `tbl_daybook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `closing_amount` double NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_daybook` (`id`, `date`, `closing_amount`, `status`) VALUES ('1', '2018-06-27', '100', '1');
INSERT INTO `tbl_daybook` (`id`, `date`, `closing_amount`, `status`) VALUES ('8', '2018-06-28', '26450', '1');
INSERT INTO `tbl_daybook` (`id`, `date`, `closing_amount`, `status`) VALUES ('14', '2018-06-29', '26450', '1');


#
# TABLE STRUCTURE FOR: tbl_finyear
#

DROP TABLE IF EXISTS `tbl_finyear`;

CREATE TABLE `tbl_finyear` (
  `finyear_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `fin_startdate` date NOT NULL,
  `fin_enddate` date NOT NULL,
  `finyear_status` int(11) NOT NULL,
  PRIMARY KEY (`finyear_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `finyear_status`) VALUES ('1', '2018-2019', '2018-04-01', '2019-03-31', '1');
INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `finyear_status`) VALUES ('2', '2017-2018', '2018-06-26', '2018-06-30', '0');


#
# TABLE STRUCTURE FOR: tbl_gusetdetails
#

DROP TABLE IF EXISTS `tbl_gusetdetails`;

CREATE TABLE `tbl_gusetdetails` (
  `guest_id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_name` varchar(50) NOT NULL,
  `guest_photo` text NOT NULL,
  `arrival_date` date NOT NULL,
  `guest_street` text NOT NULL,
  `guest_city` text NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `phone_number` bigint(20) NOT NULL,
  `idcard_number` varchar(50) NOT NULL,
  `pan_number` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `guest_status` int(11) NOT NULL,
  PRIMARY KEY (`guest_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('1', 'jobymon', '23_-01.jpg', '2018-01-15', 'ranni', 'fdgdfg', 'Kerala', 'india', '9048048024', '789456123', 'CKV123456', 'joby@gmail.com', '0');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('2', 'vishnu', 'marina.jpg', '2018-06-11', 'fgfdg', 'dfgfdg', 'Kerala', 'india', '9048048024', '789456123', '12', 'user03.wahylab@gmail.com', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('3', 'Rohan', '9bd26b59d56d65e8c76b24e8c2a868fc_featured_v2.jpg', '2018-01-22', 'thodupuzha', 'thodupuzha', 'kerala', 'india', '7845296310', '7946132589640', 'PAN784512369', 'rohan@gmail.com', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('4', 'PRAVEENKUMAR KP', 'Not uploaded', '2018-04-16', 'KOTTYAM', 'xzc', 'kerala', 'India', '9961136539', '32/254875/2002', '256482145685236695', 'praveenkp.etr@gmail.com', '0');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('5', 'anand', 'sample.png', '2018-06-13', 'htl', 'ekm', 'kerala', 'india', '9788675467', 'in35468', 'a567d45', 'aaa@s.n', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('6', 'deepak', 'deepak.jpg', '2018-06-18', 'kochi', 'kochi', 'kerala', 'india', '9048048024', '123', '12', 'd@d.com', '1');


#
# TABLE STRUCTURE FOR: tbl_product
#

DROP TABLE IF EXISTS `tbl_product`;

CREATE TABLE `tbl_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` int(11) NOT NULL,
  `hsn` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_receiptdetails
#

DROP TABLE IF EXISTS `tbl_receiptdetails`;

CREATE TABLE `tbl_receiptdetails` (
  `receipt_id` int(20) NOT NULL AUTO_INCREMENT,
  `rec_id` int(20) NOT NULL,
  `account_head` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `narration` varchar(300) NOT NULL,
  `fin_year` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `isactive` varchar(50) NOT NULL,
  `receipt_status` int(20) NOT NULL,
  PRIMARY KEY (`receipt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_receiptdetails` (`receipt_id`, `rec_id`, `account_head`, `amount`, `narration`, `fin_year`, `user_id`, `type`, `created_date`, `isactive`, `receipt_status`) VALUES ('1', '100', 'hi', '1200', ' hello', '2018-2019', '1', 'receipt', '2018-06-28', '1', '1');
INSERT INTO `tbl_receiptdetails` (`receipt_id`, `rec_id`, `account_head`, `amount`, `narration`, `fin_year`, `user_id`, `type`, `created_date`, `isactive`, `receipt_status`) VALUES ('3', '101', 'Sam\'s bill', '10000', ' ', '2018-2019', '1', 'receipt', '2018-06-26', '1', '1');


#
# TABLE STRUCTURE FOR: tbl_receiptentry
#

DROP TABLE IF EXISTS `tbl_receiptentry`;

CREATE TABLE `tbl_receiptentry` (
  `entry_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `entry_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `receipt_head` int(11) NOT NULL,
  `receiptid` int(11) NOT NULL,
  `entry_amount` double NOT NULL,
  `paidto` varchar(50) NOT NULL,
  `entry_narration` text NOT NULL,
  `entry_status` int(11) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_receiptentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `receipt_head`, `receiptid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('1', '2018-2019', '2018-06-28', '1', '1', '100', '1200', 'sim', ' ', '1');
INSERT INTO `tbl_receiptentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `receipt_head`, `receiptid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('2', '2018-2019', '2018-06-28', '1', '3', '101', '10000', 'dasdasd', ' sadsad', '1');
INSERT INTO `tbl_receiptentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `receipt_head`, `receiptid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('3', '2018-2019', '2018-06-28', '1', '3', '101', '10000', 'dfs', ' ', '1');


#
# TABLE STRUCTURE FOR: tbl_reservation
#

DROP TABLE IF EXISTS `tbl_reservation`;

CREATE TABLE `tbl_reservation` (
  `reserv_id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_id_fk` int(11) NOT NULL,
  `fin_year` varchar(20) NOT NULL,
  `created_date` date NOT NULL,
  `name` varchar(20) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `street` text NOT NULL,
  `city` text NOT NULL,
  `country` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `checkin_date` date NOT NULL,
  `checkout_date` date NOT NULL,
  `room` int(11) NOT NULL,
  `room_charge` double NOT NULL,
  `no_of_person` int(11) NOT NULL,
  `no_of_days` int(11) NOT NULL,
  `additional_charge` double NOT NULL,
  `discount` double NOT NULL,
  `subtotal` double NOT NULL,
  `paidamount` double NOT NULL,
  `balance_amount` double NOT NULL,
  `checkout_status` int(11) NOT NULL,
  `reserv_status` int(11) NOT NULL,
  PRIMARY KEY (`reserv_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_reservation` (`reserv_id`, `guest_id_fk`, `fin_year`, `created_date`, `name`, `phone`, `email`, `street`, `city`, `country`, `state`, `checkin_date`, `checkout_date`, `room`, `room_charge`, `no_of_person`, `no_of_days`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `checkout_status`, `reserv_status`) VALUES ('1', '5', '2018-2019', '2018-06-18', 'anand', '9788675467', 'aaa@s.n', 'htl', 'ekm', 'india', 'kerala', '2018-06-07', '2018-07-26', '2', '1000', '6', '49', '400', '0', '68600', '10000', '58600', '1', '1');
INSERT INTO `tbl_reservation` (`reserv_id`, `guest_id_fk`, `fin_year`, `created_date`, `name`, `phone`, `email`, `street`, `city`, `country`, `state`, `checkin_date`, `checkout_date`, `room`, `room_charge`, `no_of_person`, `no_of_days`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `checkout_status`, `reserv_status`) VALUES ('2', '0', '2018-2019', '2018-10-31', 'sdsad', '90', 'sadkashdkjh', 'sdasd', 'sadsadasd', 'sadsad', 'sdasdsad', '2018-10-23', '2018-11-30', '5', '1200', '1', '7', '10', '10', '8470', '10', '8460', '1', '1');
INSERT INTO `tbl_reservation` (`reserv_id`, `guest_id_fk`, `fin_year`, `created_date`, `name`, `phone`, `email`, `street`, `city`, `country`, `state`, `checkin_date`, `checkout_date`, `room`, `room_charge`, `no_of_person`, `no_of_days`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `checkout_status`, `reserv_status`) VALUES ('3', '0', '2018-2019', '2018-10-31', 'mahis ms', '88799878743', '[ojhkjgkg', 'klhj', 'kozz', 'jkg', 'kera;', '2018-10-11', '2018-10-18', '5', '1200', '5', '7', '1200', '10', '16800', '600', '16200', '1', '1');


#
# TABLE STRUCTURE FOR: tbl_roomdetails
#

DROP TABLE IF EXISTS `tbl_roomdetails`;

CREATE TABLE `tbl_roomdetails` (
  `room_id` int(11) NOT NULL AUTO_INCREMENT,
  `room_type` varchar(50) NOT NULL,
  `room_ac` varchar(50) NOT NULL,
  `room_number` varchar(50) NOT NULL,
  `no_of_occ` int(11) NOT NULL,
  `add_of_occ` double NOT NULL,
  `room_rate` double NOT NULL,
  `room_features` text NOT NULL,
  `occupied` int(11) NOT NULL DEFAULT '0',
  `room_active` int(11) NOT NULL,
  `room_status` int(11) NOT NULL,
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('1', '1', 'AC', 'a123', '3', '100', '500', '', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('2', '2', 'NonAC', 'b007', '4', '200', '1000', '', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('3', '1', 'AC', 'a404', '2', '200', '2000', '', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('4', '2', 'NonAC', 'b305', '4', '150', '1500', '', '0', '1', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('5', '1', 'AC', 'a201', '2', '400', '1200', '', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('6', '1', 'AC', '600', '1', '500', '200', 'dfdsf', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('7', '1', 'AC', '400', '2', '1', '500', 'gfvhgfh', '0', '1', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('8', '1', 'AC', '400', '1', '1', '200', 'dfgfdg', '0', '1', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('9', '1', 'AC', 'Asd546', '1', '1', '200', 'dsfdsfdsf', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('10', '2', 'AC', '202', '2', '0', '1200', 'Kitchen', '0', '0', '1');


#
# TABLE STRUCTURE FOR: tbl_roommaster
#

DROP TABLE IF EXISTS `tbl_roommaster`;

CREATE TABLE `tbl_roommaster` (
  `masterid` int(11) NOT NULL AUTO_INCREMENT,
  `mastername` varchar(250) NOT NULL,
  `masterdescription` text NOT NULL,
  `masterstatus` int(11) NOT NULL,
  PRIMARY KEY (`masterid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_roommaster` (`masterid`, `mastername`, `masterdescription`, `masterstatus`) VALUES ('1', 'Standard Rooms', 'dsfdsfdsf', '1');
INSERT INTO `tbl_roommaster` (`masterid`, `mastername`, `masterdescription`, `masterstatus`) VALUES ('2', 'Deluxe Rooms', 'sdfdsfds', '1');
INSERT INTO `tbl_roommaster` (`masterid`, `mastername`, `masterdescription`, `masterstatus`) VALUES ('3', 'Double Room With Kitchen', '2 Bed  And Kitchen', '1');


#
# TABLE STRUCTURE FOR: tbl_taxdetails
#

DROP TABLE IF EXISTS `tbl_taxdetails`;

CREATE TABLE `tbl_taxdetails` (
  `tax_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_name` varchar(50) NOT NULL,
  `tax_amount` double NOT NULL,
  `cgst` double NOT NULL,
  `sgst` double NOT NULL,
  `igst` double NOT NULL,
  `tax_status` int(11) NOT NULL,
  PRIMARY KEY (`tax_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_taxdetails` (`tax_id`, `tax_name`, `tax_amount`, `cgst`, `sgst`, `igst`, `tax_status`) VALUES ('1', 'Tax1', '18', '9', '9', '18', '1');


#
# TABLE STRUCTURE FOR: tbl_voucherdetails
#

DROP TABLE IF EXISTS `tbl_voucherdetails`;

CREATE TABLE `tbl_voucherdetails` (
  `voucher_id` int(11) NOT NULL AUTO_INCREMENT,
  `vouch_id` int(11) NOT NULL,
  `account_head` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `narration` text NOT NULL,
  `created_date` date NOT NULL,
  `isactive` int(11) NOT NULL,
  `fin_year` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `voucher_status` int(11) NOT NULL,
  PRIMARY KEY (`voucher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('1', '100', 'AC BILL', '1200', ' ', '2018-06-29', '1', '2018-2019', '1', 'voucher', '1');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('2', '101', 'Consultancy fee', '2000', '  pay', '2018-11-15', '1', '2018-2019', '1', 'voucher', '1');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('3', '102', 'ann\'s bill', '5000', ' ', '2018-07-05', '0', '2018-2019', '1', 'voucher', '1');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('4', '103', 'promotion fee', '3000', ' ', '2018-06-20', '0', '2018-2019', '1', 'voucher', '1');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('5', '104', 'tv ads', '5000', ' ', '2018-06-30', '0', '2018-2019', '1', 'voucher', '1');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('6', '105', 'food supply payment', '4000', ' ', '2018-07-11', '0', '2018-2019', '1', 'voucher', '0');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('7', '105', 'dszfvdsffgdsfgdgdf  bdfghdfgh', '400', ' xzcfddsfdsf', '2018-07-20', '0', '2018-2019', '1', 'voucher', '1');


#
# TABLE STRUCTURE FOR: tbl_voucherentry
#

DROP TABLE IF EXISTS `tbl_voucherentry`;

CREATE TABLE `tbl_voucherentry` (
  `entry_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `entry_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `voucher_head` int(11) NOT NULL,
  `voucherid` int(11) NOT NULL,
  `entry_amount` double NOT NULL,
  `paidto` varchar(50) NOT NULL,
  `entry_narration` text NOT NULL,
  `entry_status` int(11) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('1', '2018-2019', '2018-06-28', '1', '1', '100', '1200', 'smith', ' ', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('2', '2018-2019', '2018-06-27', '1', '2', '101', '2000', 'sim', ' ', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('3', '2018-2019', '2018-06-27', '1', '4', '103', '3000', 'wahylab', ' ', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('4', '2018-2019', '2018-08-22', '1', '5', '104', '5000', 'surya tv', ' ', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('5', '2018-2019', '2018-07-25', '1', '6', '105', '4000', 'sasi\'s mess', ' ', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('6', '2018-2019', '2018-07-11', '1', '5', '104', '10000', 'asianet', ' ', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('7', '2018-2019', '2018-07-11', '1', '6', '105', '7000', 'pi dosa', ' ', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('8', '2018-2019', '2018-06-28', '1', '1', '100', '1200', 'dasdasd', ' dsaf', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('9', '2018-2019', '2018-06-25', '1', '1', '100', '1200', 'qwerty', ' sdfg', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('10', '2018-2019', '2018-06-25', '1', '2', '101', '2000', 'sadasd', ' sadsad', '1');
INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('11', '2018-2019', '2018-10-24', '1', '1', '100', '1200', 'fsgdfhsfkgjfdgk;lh;jghk', ' sdsadasdsad', '1');


