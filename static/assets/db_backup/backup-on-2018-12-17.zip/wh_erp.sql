#
# TABLE STRUCTURE FOR: admin_login
#

DROP TABLE IF EXISTS `admin_login`;

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_password` varchar(25) NOT NULL,
  `shop_name` varchar(255) NOT NULL,
  `shop_address` text NOT NULL,
  `user_type` varchar(10) NOT NULL,
  `tin_no` varchar(255) NOT NULL,
  `gstin_no` varchar(50) NOT NULL,
  `phone_no` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  `user_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `admin_login` (`id`, `user_name`, `admin_email`, `admin_password`, `shop_name`, `shop_address`, `user_type`, `tin_no`, `gstin_no`, `phone_no`, `created_date`, `updated_date`, `user_status`) VALUES ('1', 'admin', 'marvins@gmail.com', 'admin', 'TKR Residency', ' Behind Changampuzha Park Metro Station, Mamangalam, Edappally, Kochi, Kerala 682024', 'A', 'ANFG2341234', '32ARSPK8864B1ZJ', '9656905555', '2017-12-11 16:23:47', '2017-12-11 11:11:44', '0');
INSERT INTO `admin_login` (`id`, `user_name`, `admin_email`, `admin_password`, `shop_name`, `shop_address`, `user_type`, `tin_no`, `gstin_no`, `phone_no`, `created_date`, `updated_date`, `user_status`) VALUES ('2', 'Maiz', '', '123456', '', '', 'user', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0');
INSERT INTO `admin_login` (`id`, `user_name`, `admin_email`, `admin_password`, `shop_name`, `shop_address`, `user_type`, `tin_no`, `gstin_no`, `phone_no`, `created_date`, `updated_date`, `user_status`) VALUES ('3', 'wrer', '', 'asd', '', '', 'user', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0');


#
# TABLE STRUCTURE FOR: tbl_booking
#

DROP TABLE IF EXISTS `tbl_booking`;

CREATE TABLE `tbl_booking` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `child` bigint(20) NOT NULL,
  `adults` bigint(20) NOT NULL,
  `mobnum` bigint(20) NOT NULL,
  `email` text NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`book_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_booking` (`book_id`, `startdate`, `enddate`, `child`, `adults`, `mobnum`, `email`, `status`) VALUES ('1', '2018-12-21', '2018-12-28', '2', '3', '9048048024', 'info@wahylab.com', '1');
INSERT INTO `tbl_booking` (`book_id`, `startdate`, `enddate`, `child`, `adults`, `mobnum`, `email`, `status`) VALUES ('2', '2018-12-14', '2018-12-27', '3', '3', '9048048024', 'info@wahylab.com', '1');
INSERT INTO `tbl_booking` (`book_id`, `startdate`, `enddate`, `child`, `adults`, `mobnum`, `email`, `status`) VALUES ('3', '2018-12-16', '2018-12-19', '1', '2', '8891155994', 'ivin.appu@gmail.com', '1');
INSERT INTO `tbl_booking` (`book_id`, `startdate`, `enddate`, `child`, `adults`, `mobnum`, `email`, `status`) VALUES ('4', '2018-12-16', '2018-12-19', '1', '2', '8891155994', 'ivin.appu@gmail.com', '1');
INSERT INTO `tbl_booking` (`book_id`, `startdate`, `enddate`, `child`, `adults`, `mobnum`, `email`, `status`) VALUES ('5', '2018-12-13', '2018-12-22', '1', '2', '8891155994', 'so01.wahylab@gmail.com', '1');
INSERT INTO `tbl_booking` (`book_id`, `startdate`, `enddate`, `child`, `adults`, `mobnum`, `email`, `status`) VALUES ('6', '2018-12-17', '2018-12-18', '1', '1', '0', '', '1');
INSERT INTO `tbl_booking` (`book_id`, `startdate`, `enddate`, `child`, `adults`, `mobnum`, `email`, `status`) VALUES ('7', '2018-12-17', '2018-12-18', '1', '1', '8111846660', 'aaarshadkhan@gmail.com', '1');


#
# TABLE STRUCTURE FOR: tbl_checkin
#

DROP TABLE IF EXISTS `tbl_checkin`;

CREATE TABLE `tbl_checkin` (
  `check_id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_id_fk` int(11) NOT NULL,
  `rev_id_fk` int(11) NOT NULL,
  `tax_id_fk` int(11) NOT NULL,
  `fin_year` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `street` text NOT NULL,
  `country` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `checkin_number` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `checkin_date` date NOT NULL,
  `no_of_days` varchar(20) NOT NULL,
  `no_of_person` varchar(20) NOT NULL,
  `person_plus` int(11) NOT NULL,
  `checkout_date` date NOT NULL,
  `notes` text NOT NULL,
  `rooms` varchar(50) NOT NULL,
  `room_charge` double NOT NULL,
  `additional_charge` double NOT NULL,
  `discount` double NOT NULL,
  `subtotal` double NOT NULL,
  `paidamount` double NOT NULL,
  `balance_amount` double NOT NULL,
  `cin_status` int(11) NOT NULL,
  `checkin_status` int(11) NOT NULL,
  PRIMARY KEY (`check_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_checkin` (`check_id`, `guest_id_fk`, `rev_id_fk`, `tax_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('1', '1', '0', '1', '2018-2019', 'sanju', 'restyys', 'FDJHBGKJFDSGHK', 'gsjh ', 'FDJHGBKJDSHGFKJDSFGF', '999999999999', 'sanju@gmail.com', '1', '2018-12-17', '2018-12-17', '10', '3', '1', '2018-12-27', 'fgfdg', '1', '150', '100', '10', '1699.2', '100', '1599.2', '0', '1');


#
# TABLE STRUCTURE FOR: tbl_checkout
#

DROP TABLE IF EXISTS `tbl_checkout`;

CREATE TABLE `tbl_checkout` (
  `checkout_id` int(11) NOT NULL AUTO_INCREMENT,
  `check_id_fk` int(11) NOT NULL,
  `rev_id_fk` int(11) NOT NULL,
  `fin_year` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `guest_id_fk` int(11) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `street` text NOT NULL,
  `city` text NOT NULL,
  `country` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `checkout_number` int(11) NOT NULL,
  `checkin_date` date NOT NULL,
  `no_of_person` varchar(50) NOT NULL,
  `checkout_date` date NOT NULL,
  `notes` text NOT NULL,
  `balance_amount` double NOT NULL,
  `payment_mode` varchar(50) NOT NULL,
  `cout_status` int(11) NOT NULL,
  `checkout_status` int(11) NOT NULL,
  PRIMARY KEY (`checkout_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_checkout` (`checkout_id`, `check_id_fk`, `rev_id_fk`, `fin_year`, `name`, `guest_id_fk`, `phone`, `email`, `street`, `city`, `country`, `state`, `created_date`, `checkout_number`, `checkin_date`, `no_of_person`, `checkout_date`, `notes`, `balance_amount`, `payment_mode`, `cout_status`, `checkout_status`) VALUES ('1', '1', '0', '2018-2019', 'sanju', '1', '999999999999', 'sanju@gmail.com', 'restyys', 'gsjh ', 'FDJHBGKJFDSGHK', 'FDJHGBKJDSHGFKJDSFGF', '2018-12-17', '1', '2018-12-17', '3', '2018-12-27', 'fgfdg', '1599.2', 'cash', '1', '1');


#
# TABLE STRUCTURE FOR: tbl_daybook
#

DROP TABLE IF EXISTS `tbl_daybook`;

CREATE TABLE `tbl_daybook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `closing_amount` double NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_finyear
#

DROP TABLE IF EXISTS `tbl_finyear`;

CREATE TABLE `tbl_finyear` (
  `finyear_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `fin_startdate` date NOT NULL,
  `fin_enddate` date NOT NULL,
  `finyear_status` int(11) NOT NULL,
  PRIMARY KEY (`finyear_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `finyear_status`) VALUES ('1', '2018-2019', '2018-04-01', '2019-03-31', '0');
INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `finyear_status`) VALUES ('2', '2017-2018', '2018-06-26', '2018-06-30', '0');
INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `finyear_status`) VALUES ('3', '2020-2021', '2018-12-20', '2018-12-29', '1');


#
# TABLE STRUCTURE FOR: tbl_gusetdetails
#

DROP TABLE IF EXISTS `tbl_gusetdetails`;

CREATE TABLE `tbl_gusetdetails` (
  `guest_id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_name` varchar(50) NOT NULL,
  `guest_photo` text NOT NULL,
  `arrival_date` date NOT NULL,
  `guest_street` text NOT NULL,
  `guest_city` text NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `phone_number` bigint(20) NOT NULL,
  `idcard_number` varchar(50) NOT NULL,
  `pan_number` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `guest_status` int(11) NOT NULL,
  PRIMARY KEY (`guest_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('1', 'sanju', '20181204_120210.jpeg', '2018-12-17', 'restyys', 'gsjh ', 'FDJHGBKJDSHGFKJDSFGF', 'FDJHBGKJFDSGHK', '999999999999', '4675868', '44655768679', 'sanju@gmail.com', '1');


#
# TABLE STRUCTURE FOR: tbl_receiptdetails
#

DROP TABLE IF EXISTS `tbl_receiptdetails`;

CREATE TABLE `tbl_receiptdetails` (
  `receipt_id` int(20) NOT NULL AUTO_INCREMENT,
  `rec_id` int(20) NOT NULL,
  `account_head` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `narration` varchar(300) NOT NULL,
  `fin_year` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `isactive` varchar(50) NOT NULL,
  `receipt_status` int(20) NOT NULL,
  PRIMARY KEY (`receipt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_receiptdetails` (`receipt_id`, `rec_id`, `account_head`, `amount`, `narration`, `fin_year`, `user_id`, `type`, `created_date`, `isactive`, `receipt_status`) VALUES ('1', '100', ' mnvbg', '200', ' fdgfdgfdg', '2018-2019', '1', 'receipt', '2018-12-17', '0', '1');


#
# TABLE STRUCTURE FOR: tbl_receiptentry
#

DROP TABLE IF EXISTS `tbl_receiptentry`;

CREATE TABLE `tbl_receiptentry` (
  `entry_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `entry_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `receipt_head` int(11) NOT NULL,
  `receiptid` int(11) NOT NULL,
  `entry_amount` double NOT NULL,
  `paidto` varchar(50) NOT NULL,
  `entry_narration` text NOT NULL,
  `entry_status` int(11) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_receiptentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `receipt_head`, `receiptid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('1', '2018-2019', '2018-12-17', '1', '1', '100', '200', 'tyytuytu', ' fghgfhgfh', '1');


#
# TABLE STRUCTURE FOR: tbl_reservation
#

DROP TABLE IF EXISTS `tbl_reservation`;

CREATE TABLE `tbl_reservation` (
  `reserv_id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_id_fk` int(11) NOT NULL,
  `fin_year` varchar(20) NOT NULL,
  `created_date` date NOT NULL,
  `name` varchar(20) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `street` text NOT NULL,
  `city` text NOT NULL,
  `country` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `checkin_date` date NOT NULL,
  `checkout_date` date NOT NULL,
  `room` int(11) NOT NULL,
  `room_charge` double NOT NULL,
  `no_of_person` int(11) NOT NULL,
  `no_of_days` int(11) NOT NULL,
  `additional_charge` double NOT NULL,
  `discount` double NOT NULL,
  `subtotal` double NOT NULL,
  `paidamount` double NOT NULL,
  `balance_amount` double NOT NULL,
  `checkout_status` int(11) NOT NULL,
  `reserv_status` int(11) NOT NULL,
  PRIMARY KEY (`reserv_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_reservation` (`reserv_id`, `guest_id_fk`, `fin_year`, `created_date`, `name`, `phone`, `email`, `street`, `city`, `country`, `state`, `checkin_date`, `checkout_date`, `room`, `room_charge`, `no_of_person`, `no_of_days`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `checkout_status`, `reserv_status`) VALUES ('1', '1', '2018-2019', '2018-12-17', 'sanju', '999999999999', 'sanju@gmail.com', 'restyys', 'gsjh ', 'FDJHBGKJFDSGHK', 'FDJHGBKJDSHGFKJDSFGF', '2018-12-19', '2018-12-22', '4', '350', '1', '3', '100', '10', '1350', '100', '1250', '0', '1');


#
# TABLE STRUCTURE FOR: tbl_roomdetails
#

DROP TABLE IF EXISTS `tbl_roomdetails`;

CREATE TABLE `tbl_roomdetails` (
  `room_id` int(11) NOT NULL AUTO_INCREMENT,
  `room_type` varchar(50) NOT NULL,
  `room_ac` varchar(50) NOT NULL,
  `room_number` varchar(50) NOT NULL,
  `room_pic` text NOT NULL,
  `no_of_occ` int(11) NOT NULL,
  `add_of_occ` double NOT NULL,
  `room_rate` double NOT NULL,
  `room_features` text NOT NULL,
  `occupied` int(11) NOT NULL DEFAULT '0',
  `room_active` int(11) NOT NULL,
  `room_status` int(11) NOT NULL,
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('1', '1', 'AC', '100', '20181204_120240.jpeg', '2', '100', '150', 'ACCOMMADATION:A/C DOUBLE BED,WITH AIRCONDICATION,SIDE TABLE,DRESSING CUBOARD WITH MIRROR,AND A CLEAN TOILET,BATH ROOM EQUIPPED WITH EUROPEAN CLOSET,WASH BASIN WITH MIRROR,HOT AND COLD SHOWER,LED TV,Wi Fi,TOWEL,SOAP,SHAMPOO AND DRINKING WATER,RATE:   Rupees 2500 WITH NO HIDDEN CHARGES. ', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('2', '1', 'NonAC', '101', '20181204_120426.jpeg', '3', '150', '200', 'BEATUTIFUL AND COZY A/C ROOM WITH KING SIZE SOFA BEDS,SIDE TABLE,DIWAN COT SOFA,DRESSING CUBOARD WITH MIRROR,AND A CLEAN TOILET,BATH ROOM EQUIPPED WITH EUROPEAN CLOSET,WASH BASIN WITH MIRROR,HOT AND COLD SHOWER,LED TV,Wi Fi,TOWEL,SOAP,SHAMPOO AND DRINKING WATER,RATE:Rupees 3500 WITH NO HIDDEN CHARGES.FIT FOR HONEYMOON COUPLES OR A FAMILY. ', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('3', '1', 'AC', '102', '20181204_120516.jpeg', '3', '250', '300', 'A/C SUIT ROOM LARGE,WITH AIRCONDICATION,TWO KING SIZE BEDS IN SPECIOUS ROOM.A SEPARATE HALL.FIT FOR A BIG FAMILY(SIX PEOPLE CAN STAY) SUIT FOR A PRINCE WITH SIDE TABLE,DRESSING CUBOARD WITH MIRROR,AND A CLEAN TOILET,BATH ROOM EQUIPPED WITH EUROPEAN CLOSET,WASH BASIN WITH MIRROR,HOT AND COLD SHOWER,LED TV,Wi Fi,TOWEL,SOAP,SHAMPOO AND DRINKING WATER,RATE:Rupees 4000 WITH NO HIDDEN CHARGES. ', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('4', '1', 'AC', '103', '20181204_121605.jpeg', '2', '220', '350', 'SIMPLE AND ELEGENT DOUBLE BED NON A/C ROOMS,SIDE TABLE,DRESSING CUBOARD WITH MIRROR,AND A CLEAN TOILET,BATH ROOM EQUIPPED WITH EUROPEAN CLOSET,WASH BASIN WITH MIRROR,HOT AND COLD SHOWER,LED TV,TOWEL,SOAP,SHAMPOO AND DRINKING WATER,RATE:   Rupees 2000 WITH NO HIDDEN CHARGES. CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('5', '1', 'NonAC', '104', '20181204_121626.jpeg', '2', '200', '350', 'DORMITORIES,WITH FIVE TO SIX BEDS,HOT AND COLD WATER SHOWER.A CLEAN ENVIRONMENT.RATE:Rs350 PER BED.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('6', '1', 'AC', '105', '20181204_122021.jpeg', '1', '200', '320', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.', '0', '0', '0');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('7', '1', 'NonAC', '106', '20181204_122848.jpeg', '1', '200', '500', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.', '0', '0', '0');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('8', '1', 'AC', '123', '20181204_121309.jpeg', '2', '100', '500', 'sdfdsfdsf dfgdfg dsfdsfdsfds', '0', '1', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('9', '1', 'AC', '807', '20181204_115711.jpeg', '2', '300', '600', 'cvbcvbcvb dfdsfsdfds', '1', '0', '1');


#
# TABLE STRUCTURE FOR: tbl_roommaster
#

DROP TABLE IF EXISTS `tbl_roommaster`;

CREATE TABLE `tbl_roommaster` (
  `masterid` int(11) NOT NULL AUTO_INCREMENT,
  `mastername` varchar(250) NOT NULL,
  `masterdescription` text NOT NULL,
  `masterstatus` int(11) NOT NULL,
  PRIMARY KEY (`masterid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_roommaster` (`masterid`, `mastername`, `masterdescription`, `masterstatus`) VALUES ('1', 'STANDARD ROOM', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.', '1');
INSERT INTO `tbl_roommaster` (`masterid`, `mastername`, `masterdescription`, `masterstatus`) VALUES ('2', 'Deluxe Rooms', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.', '1');
INSERT INTO `tbl_roommaster` (`masterid`, `mastername`, `masterdescription`, `masterstatus`) VALUES ('3', 'Double Room With Kitchen', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.', '1');
INSERT INTO `tbl_roommaster` (`masterid`, `mastername`, `masterdescription`, `masterstatus`) VALUES ('4', 'wyteruywerih', 'dfgfdg dfgfgfdgfdg ', '0');


#
# TABLE STRUCTURE FOR: tbl_taxdetails
#

DROP TABLE IF EXISTS `tbl_taxdetails`;

CREATE TABLE `tbl_taxdetails` (
  `tax_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_name` varchar(50) NOT NULL,
  `tax_amount` double NOT NULL,
  `cgst` double NOT NULL,
  `sgst` double NOT NULL,
  `igst` double NOT NULL,
  `tax_status` int(11) NOT NULL,
  PRIMARY KEY (`tax_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_taxdetails` (`tax_id`, `tax_name`, `tax_amount`, `cgst`, `sgst`, `igst`, `tax_status`) VALUES ('1', 'Tax1', '18', '9', '9', '18', '1');
INSERT INTO `tbl_taxdetails` (`tax_id`, `tax_name`, `tax_amount`, `cgst`, `sgst`, `igst`, `tax_status`) VALUES ('2', '4jfgj', '50', '25', '25', '50', '1');
INSERT INTO `tbl_taxdetails` (`tax_id`, `tax_name`, `tax_amount`, `cgst`, `sgst`, `igst`, `tax_status`) VALUES ('3', 'GST 18% split', '18', '9', '9', '18', '1');
INSERT INTO `tbl_taxdetails` (`tax_id`, `tax_name`, `tax_amount`, `cgst`, `sgst`, `igst`, `tax_status`) VALUES ('4', 'GST 28% split tax', '28', '14', '14', '28', '1');


#
# TABLE STRUCTURE FOR: tbl_voucherdetails
#

DROP TABLE IF EXISTS `tbl_voucherdetails`;

CREATE TABLE `tbl_voucherdetails` (
  `voucher_id` int(11) NOT NULL AUTO_INCREMENT,
  `vouch_id` int(11) NOT NULL,
  `account_head` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `narration` text NOT NULL,
  `created_date` date NOT NULL,
  `isactive` int(11) NOT NULL,
  `fin_year` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `voucher_status` int(11) NOT NULL,
  PRIMARY KEY (`voucher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('1', '100', 'dfgfdhgfdh', '100', ' dfgfdgfdgfdg', '2018-12-17', '0', '2018-2019', '1', 'voucher', '1');


#
# TABLE STRUCTURE FOR: tbl_voucherentry
#

DROP TABLE IF EXISTS `tbl_voucherentry`;

CREATE TABLE `tbl_voucherentry` (
  `entry_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `entry_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `voucher_head` int(11) NOT NULL,
  `voucherid` int(11) NOT NULL,
  `entry_amount` double NOT NULL,
  `paidto` varchar(50) NOT NULL,
  `entry_narration` text NOT NULL,
  `entry_status` int(11) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('1', '2018-2019', '2018-12-26', '1', '1', '100', '100', 'kseb', ' fcvgcxvcxv', '1');


