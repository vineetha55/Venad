#
# TABLE STRUCTURE FOR: admin_login
#

DROP TABLE IF EXISTS `admin_login`;

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_password` varchar(25) NOT NULL,
  `shop_name` varchar(255) NOT NULL,
  `shop_address` text NOT NULL,
  `user_type` varchar(10) NOT NULL,
  `tin_no` varchar(255) NOT NULL,
  `gstin_no` varchar(50) NOT NULL,
  `phone_no` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  `user_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `admin_login` (`id`, `user_name`, `admin_email`, `admin_password`, `shop_name`, `shop_address`, `user_type`, `tin_no`, `gstin_no`, `phone_no`, `created_date`, `updated_date`, `user_status`) VALUES ('1', 'admin', 'marvins@gmail.com', 'admin1234!', 'TKR Residency', ' Behind Changampuzha Park Metro Station, Mamangalam, Edappally, Kochi, Kerala 682024', 'A', 'ANFG2341234', '32ARSPK8864B1ZJ', '9656905555', '2017-12-11 16:23:47', '2017-12-11 11:11:44', '0');
INSERT INTO `admin_login` (`id`, `user_name`, `admin_email`, `admin_password`, `shop_name`, `shop_address`, `user_type`, `tin_no`, `gstin_no`, `phone_no`, `created_date`, `updated_date`, `user_status`) VALUES ('2', 'Maiz', '', 'qwerty', '', '', 'user', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0');
INSERT INTO `admin_login` (`id`, `user_name`, `admin_email`, `admin_password`, `shop_name`, `shop_address`, `user_type`, `tin_no`, `gstin_no`, `phone_no`, `created_date`, `updated_date`, `user_status`) VALUES ('3', 'wrer', '', 'asd', '', '', 'user', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0');
INSERT INTO `admin_login` (`id`, `user_name`, `admin_email`, `admin_password`, `shop_name`, `shop_address`, `user_type`, `tin_no`, `gstin_no`, `phone_no`, `created_date`, `updated_date`, `user_status`) VALUES ('4', 'hari', '', 'hari2018', '', '', 'user', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0');
INSERT INTO `admin_login` (`id`, `user_name`, `admin_email`, `admin_password`, `shop_name`, `shop_address`, `user_type`, `tin_no`, `gstin_no`, `phone_no`, `created_date`, `updated_date`, `user_status`) VALUES ('5', 'altab', '', 'altab1234', '', '', '', '', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0');


#
# TABLE STRUCTURE FOR: tbl_booking
#

DROP TABLE IF EXISTS `tbl_booking`;

CREATE TABLE `tbl_booking` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(250) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `child` bigint(20) NOT NULL,
  `adults` bigint(20) NOT NULL,
  `mobnum` bigint(20) NOT NULL,
  `email` text NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_checkin
#

DROP TABLE IF EXISTS `tbl_checkin`;

CREATE TABLE `tbl_checkin` (
  `check_id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_name` int(11) NOT NULL,
  `guest_id_fk` int(11) NOT NULL,
  `rev_id_fk` int(11) NOT NULL,
  `tax_id_fk` int(11) NOT NULL,
  `fin_year` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `street` text NOT NULL,
  `country` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `checkin_number` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `checkin_date` date NOT NULL,
  `no_of_days` varchar(20) NOT NULL,
  `no_of_person` varchar(20) NOT NULL,
  `person_plus` int(11) NOT NULL,
  `checkout_date` date NOT NULL,
  `notes` text NOT NULL,
  `rooms` varchar(50) NOT NULL,
  `room_charge` double NOT NULL,
  `additional_charge` double NOT NULL,
  `discount` double NOT NULL,
  `subtotal` double NOT NULL,
  `paidamount` double NOT NULL,
  `balance_amount` double NOT NULL,
  `cin_status` int(11) NOT NULL,
  `checkin_status` int(11) NOT NULL,
  PRIMARY KEY (`check_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_checkin` (`check_id`, `hotel_name`, `guest_id_fk`, `rev_id_fk`, `tax_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('1', '0', '8', '0', '1', '2018-2019', 'Augustin Livingston G', 'Vattappara', 'India', 'Trivandrum', 'Kerala', '8547286002', 'augustin@gmail.com', '1', '2019-05-07', '2019-05-09', '4', '2', '0', '2019-05-13', '', '25', '1000', '0', '0', '4480', '1000', '3480', '1', '1');
INSERT INTO `tbl_checkin` (`check_id`, `hotel_name`, `guest_id_fk`, `rev_id_fk`, `tax_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('2', '0', '10', '0', '1', '2018-2019', 'Muhammad Younus', 'Kottapadam', 'India', 'Mannarkkad', 'Kerala', '8137817294', 'nil', '2', '2019-05-08', '2019-05-08', '21', '3', '1', '2019-05-30', '', '26', '1000', '0', '0', '23520', '5000', '18520', '1', '1');
INSERT INTO `tbl_checkin` (`check_id`, `hotel_name`, `guest_id_fk`, `rev_id_fk`, `tax_id_fk`, `fin_year`, `name`, `street`, `country`, `city`, `state`, `phone`, `email`, `checkin_number`, `created_date`, `checkin_date`, `no_of_days`, `no_of_person`, `person_plus`, `checkout_date`, `notes`, `rooms`, `room_charge`, `additional_charge`, `discount`, `subtotal`, `paidamount`, `balance_amount`, `cin_status`, `checkin_status`) VALUES ('3', '0', '13', '0', '1', '2018-2019', 'suresh babu', 'Yayath , Valayandhinagar P.O', 'India', 'Perumbavoor', 'Kerala', '8589039013', 'nil', '3', '2019-05-09', '2019-05-09', '20', '4', '2', '2019-05-29', '', '28', '1000', '0', '0', '22400', '10000', '12400', '1', '1');


#
# TABLE STRUCTURE FOR: tbl_checkout
#

DROP TABLE IF EXISTS `tbl_checkout`;

CREATE TABLE `tbl_checkout` (
  `checkout_id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_name` int(11) NOT NULL,
  `check_id_fk` int(11) NOT NULL,
  `rev_id_fk` int(11) NOT NULL,
  `fin_year` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `guest_id_fk` int(11) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `street` text NOT NULL,
  `city` text NOT NULL,
  `country` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `checkout_number` int(11) NOT NULL,
  `checkin_date` date NOT NULL,
  `no_of_person` varchar(50) NOT NULL,
  `checkout_date` date NOT NULL,
  `notes` text NOT NULL,
  `balance_amount` double NOT NULL,
  `payment_mode` varchar(50) NOT NULL,
  `cout_status` int(11) NOT NULL,
  `checkout_status` int(11) NOT NULL,
  PRIMARY KEY (`checkout_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_daybook
#

DROP TABLE IF EXISTS `tbl_daybook`;

CREATE TABLE `tbl_daybook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `closing_amount` double NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_daybook` (`id`, `date`, `closing_amount`, `status`) VALUES ('1', '2019-05-05', '12000', '1');
INSERT INTO `tbl_daybook` (`id`, `date`, `closing_amount`, `status`) VALUES ('2', '2019-05-08', '4200', '1');


#
# TABLE STRUCTURE FOR: tbl_finyear
#

DROP TABLE IF EXISTS `tbl_finyear`;

CREATE TABLE `tbl_finyear` (
  `finyear_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `fin_startdate` date NOT NULL,
  `fin_enddate` date NOT NULL,
  `finyear_status` int(11) NOT NULL,
  PRIMARY KEY (`finyear_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `finyear_status`) VALUES ('1', '2018-2019', '2018-04-01', '2019-03-31', '1');
INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `finyear_status`) VALUES ('2', '2017-2018', '2018-06-26', '2018-06-30', '0');
INSERT INTO `tbl_finyear` (`finyear_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `finyear_status`) VALUES ('3', '2020-2021', '2018-12-20', '2018-12-29', '0');


#
# TABLE STRUCTURE FOR: tbl_gusetdetails
#

DROP TABLE IF EXISTS `tbl_gusetdetails`;

CREATE TABLE `tbl_gusetdetails` (
  `guest_id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_name` varchar(50) NOT NULL,
  `guest_photo` text NOT NULL,
  `arrival_date` date NOT NULL,
  `guest_street` text NOT NULL,
  `guest_city` text NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `phone_number` bigint(20) NOT NULL,
  `idcard_number` varchar(50) NOT NULL,
  `pan_number` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `guest_status` int(11) NOT NULL,
  PRIMARY KEY (`guest_id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('1', 'sanju', '20181204_120210.jpeg', '2018-12-17', 'restyys', 'gsjh ', 'FDJHGBKJDSHGFKJDSFGF', 'FDJHBGKJFDSGHK', '999999999999', '4675868', '44655768679', 'sanju@gmail.com', '0');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('2', 'Shanif', '_MG_0012.jpg', '2018-12-18', 'second', 'Trivandrum', 'Kerala', 'India', '8111846667', '121/1212/12', '211212323232', 'aaarshadkhan@gmail.com', '0');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('3', 'joby', '', '2018-12-14', '', '', '', '', '0', '', '', '', '0');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('4', 'joby3', '', '2018-12-13', '', '', '', '', '0', '', '', '', '0');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('5', 'Arun', '', '2018-12-12', '', '', '', '', '0', '', '', '', '0');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('6', 'Arun', '', '2018-12-28', '', '', '', '', '0', '', '', '', '0');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('7', 'David', '', '2018-12-21', '', '', '', '', '0', '', '', '', '0');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('8', 'Augustin Livingston G', '1_Augustin_Livingston.jpg', '2018-12-31', 'Vattappara', 'Trivandrum', 'Kerala', 'India', '8547286002', '21/384/2017', 'Driving License', 'augustin@gmail.com', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('9', 'Boban CJ', 'Boban_CJ_1.png', '2019-01-02', 'Chakalakandathil House, Chendamagalam P.O, North Paravur', 'Ernakulam', 'Keraka', 'India', '0', 'DL 42/6103/2009', 'NIL', 'NIL', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('10', 'Muhammad Younus', '', '2019-01-02', 'Kottapadam', 'Mannarkkad', 'Kerala', 'India', '8137817294', 'Voter : ZET0118349', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('11', 'Malwa Choudary', '', '2019-01-04', 'B6/21 , pitambspra', 'varanasi', 'UP', 'india', '9453048649', 'aadhar 791678830620', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('12', 'Abbas', '', '2019-01-04', 'Plamoottil', 'Muvvattupuzha', 'Kerala', 'India', '9744777727', 'Passport : H4807689', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('13', 'suresh babu', '', '2019-01-05', 'Yayath , Valayandhinagar P.O', 'Perumbavoor', 'Kerala', 'India', '8589039013', 'Voter : URJ0413518', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('14', 'surendra kumar sharma', '', '2019-01-05', 'nirmal bagh', 'Dehradun', 'Uttarakhand', 'India', '7409010107', 'Aadhar : 938408755941', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('15', 'Ashish Gupta', '', '2019-01-05', 'Company Bagh', 'Barabanki', 'U P', 'India', '9415189409', 'Aadhar : 363544653307', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('16', 'Hari Mon MT', '', '2019-01-06', 'Valanchery', 'Malappuram', 'Kerala', 'India', '9048484831', 'Voters: SKL0092098', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('17', 'Abhishek', '', '2019-01-06', 'Arummuli', 'Arummuli', 'Maharastra', 'India', '9096460730', 'Voter : XKU6299275', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('18', 'Harish Raghuvanshi', '', '2019-01-06', 'Bank Colony', 'Indore', 'Madhya Pradesh', 'India', '9111672110', 'D/L : MP09R/2014/0973607', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('19', 'K J Joseph', '', '2019-01-07', 'Vile Parle east', 'Mumbai', 'Maharastra', 'India', '9820779846', 'Indian Customs : CM 4100', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('20', 'b m maru', '', '2019-01-07', 'pujaraplot', 'rajkot', 'gujarat', 'India', '9428710942', 'adadhar 461372477336', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('21', 'Kalai arasan', '', '2019-01-07', 'Arumbakam', 'Chennai', 'Tamil Nadu', 'India', '0', 'DL : TN02/20160000744', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('22', 'Binu Lal PS', '', '2019-01-07', 'Thattamoola', 'Kollam', 'Kerala', 'India', '0', 'DL : 2/537/1999', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('23', 'Alfred', '', '2019-01-07', 'Venganoor', 'Trivandrum', 'Kerala', 'India', '0', 'nil', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('24', 'Jiby V G', '', '2019-01-07', 'Methri P O', 'Ramapuram', 'Kerala', 'India', '9961474505', 'DL : 35/2095/2010', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('25', 'Sanjay soni', '', '2019-01-07', 'Deklab', 'Rewa', 'Madhya Pradesh', 'India', '9425469522', 'Aadhar : 426005744675', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('26', 'Arshad Khan', '', '2019-02-08', 'NIl', 'Trivandrum', 'Kerala', 'India', '8111846667', 'xxxxxxxxx', 'NIl', 'aaarshadkhan@gmail.com', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('27', 'salim bhai', '', '2019-01-10', 'nagpur', 'nagpur', 'Maharashtra', 'India', '0', 'nil', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('28', 'R Balachander', '', '2019-01-10', '30 Velappar St', 'Anappukkottai', 'Tamilnadu', 'India', '9498179013', 'DL : TN67/2008/0003316', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('29', 'Narayanan', '', '2019-01-15', 'thirunelveli', 'Thirunelveli', 'Thamilnadu', 'India', '8438434726', '246874375311', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('30', 'Fayas Ahmed', '', '2019-01-16', 'Ugargol', 'Dharwad', 'Karnadaka', 'India', '0', '423643927714', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('31', 'Fayaz Ahmed', '', '2019-01-16', 'Ugargol  ', 'ugargol', 'Karnadaka', 'India', '6238470475', '423643927714', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('32', 'Anto  John', '', '2019-01-16', 'Ollur', 'Ollur', 'Kerala', 'India', '9995068783', '8/1383/2008', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('33', 'Anto  John', '', '2019-01-16', 'Ollur', 'Ollur', 'Kerala', 'India', '9995068783', '8/1383/2008', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('34', 'Ajay Kumar', '', '2019-01-16', 'Navayuva Complex', 'Chintal , Hyderabad', 'Telangana', 'India', '7799881502', 'nil', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('35', 'sreeju', '', '2019-01-18', 'thaliyal', 'Trivandrum', 'Kerala', 'India', '974646808', '916691142563', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('36', 'renjith', '', '2019-01-18', 'mala', 'Ernakulam', 'Kerala', 'India', '9947992213', 'Passport : L9816454', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('37', 'Aneesh', '', '2019-01-20', 'Kamukinkodu', 'Trivandrum', 'Kerala', 'India', '8689389720', 'XAA0192260', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('38', 'Riyas Mydeen', '', '2019-01-21', '489 N,  no:39/1, Sambanthapuram, Seetakathi St', 'Rajapalam', 'Tamilnadu', 'India', '9629141568', 'DL : TN67Z/2008/0001728', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('39', 'binjil', '', '2019-01-22', 'kuruvalasery', 'trichur', 'Kerala', 'India', '9747171706', 'aadhar : 741480073518', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('40', 'manoharan gunaselvam', '', '2019-01-22', 'Sastri Nagar', 'Chennai', 'Tamilnadu', 'India', '7397335276', 'Aadhar : 675815543764 (Karunakaran SR)', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('41', 'Rasheena', '', '2019-01-22', 'Kalayamkunne (H), Chanthapura, Puducode', 'Palakkad', 'Kerala', 'India', '9895549286', 'Aadhar : 758970472176', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('42', 'K S Vanarajan', '', '2019-01-23', '47/5 , Sokkanathapuram , SPK Road , Chinnamanur , Uttamapalayam', 'Theni', 'Tamilnadu', 'India', '9894657619', 'Aadhar : 913938657667', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('43', 'Fahad Bin Abdul Rahman', '', '2019-01-25', 'Mattanchery', 'Ernakulam', 'Kerala', 'India', '9846732253', '273881310715', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('44', 'Kafil', '', '2019-01-25', 'saharanpur', 'saharanpur', 'Uttarpradhesh', 'India', '8650516771', '367702714048', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('45', 'midhum', '', '2019-01-26', 'valayil', 'kadakkad', 'kerala', 'india', '9744894848', 'dl 25/3031/2009', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('46', 'vijayakumar', '', '2019-01-26', 'kottapuram', 'vizhinjam', 'kerala', 'india', '0', 'aadhar 212887080739', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('47', 'rajesh kanna', '', '2019-01-26', 'kumbakonam', 'kumbakonam', 'tamilnadu', 'india', '9597386828', 'aadhar 237835308078', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('48', 'shivom', '', '2019-01-27', '422-A , Sethmishri lal Nagar', 'Dewas', 'Madhya Pradesh', 'India', '9179886725', 'aadhar 922703481589', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('49', 'Bridgit', '', '2019-01-28', 'chapparapadavu', 'kannur', 'Kerala', 'India', '9539690413', 'voter sdx0265843', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('50', 'shivaji y korvi', '', '2019-01-28', 'kadamwadi road , near menam banglow', 'Kolhapur', 'maharastra', 'india', '8421015210', 'aadhar 882184425878', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('51', 'sreenath n', '', '2019-01-28', 'parekudath', 'thirunavaju', 'kerala', 'india', '9526797799', 'voter zvt0471631', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('52', 'Karunesh Srimani', '', '2019-02-04', 'Manikotala', 'Manikotala', 'Utrarpredesh', 'India', '0', 'Elec JSC2365187 ', '23', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('53', 'Arshad - Test', '', '2019-02-09', 'Kovalam', 'Trivandrum', 'Kerala', 'India', '77878787', '121212121', '121212121', 'aaaaaaa@gmail.com', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('54', 'JESSWIN W VARGHESES', '', '2019-02-12', 'Kidagannur', 'Pathanamthitta', 'Kerala', 'India', '9446178937', 'DL 30/2913/2018', 'Nil', 'Nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('55', 'sulfex mattress company', '', '2019-02-13', 'parassinikadavu', 'kannur', 'Kerala', 'India', '70259393', '4972780747', 'nil', 'sulfexindia@gmail.com', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('56', 'PRAVEEN BABU', '', '2019-02-13', 'PONMARI ILLAM', 'TIRUPUR', 'Tamil Nadu', 'India', '9894843010', 'ADHAAR 709034264715', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('57', 'AbduSalam L V', '', '2019-02-13', 'Mottemmal, Kaniyankandiyil, Eramala Post', 'Vadakara', 'Kerala', 'India', '0', 'DL 18/4379/2003', 'NIl', 'NIl', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('58', 'revi k', '', '2019-02-15', 'adukkadukkam,  kottodi p o, rajapuram', 'kasaragod.dt', 'Kerala', 'India', '9961864368', 'dl 60/1940/1993', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('59', 'Mahesh Dalal', '', '2019-02-14', 'Sai ashish', 'SAI ASHISH', 'Gujarat', 'India', '9427578777', 'dl 0002160082', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('60', 'Mydheen sahul hameed', '', '2019-02-15', 'aruppkkottai', 'kattu bava north', 'Tamil Nadu', 'India', '9150504545', 'aadhar641251833496', 'nil', 'nil', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('61', 'gf', '', '2019-03-13', '', '', '', '', '0', '', '', '', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('62', 'dfgfdgfdgfdgfdg', '', '2019-03-20', '', '', '', '', '0', '', '', '', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('63', 'Test from mail', '', '2019-03-13', '', '', '', '', '0', '', '', '', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('64', 'joby', '', '2019-03-14', '', '', '', '', '0', '', '', '', '1');
INSERT INTO `tbl_gusetdetails` (`guest_id`, `guest_name`, `guest_photo`, `arrival_date`, `guest_street`, `guest_city`, `state`, `country`, `phone_number`, `idcard_number`, `pan_number`, `email`, `guest_status`) VALUES ('65', '', '', '1970-01-01', '', '', '', '', '0', '', '', '', '1');


#
# TABLE STRUCTURE FOR: tbl_partialpay
#

DROP TABLE IF EXISTS `tbl_partialpay`;

CREATE TABLE `tbl_partialpay` (
  `pay_id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_id_fk` int(11) NOT NULL,
  `check_id` int(11) NOT NULL,
  `pat_amount` double NOT NULL,
  `pay_status` int(11) NOT NULL,
  PRIMARY KEY (`pay_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_partialpay` (`pay_id`, `guest_id_fk`, `check_id`, `pat_amount`, `pay_status`) VALUES ('1', '8', '1', '10', '1');
INSERT INTO `tbl_partialpay` (`pay_id`, `guest_id_fk`, `check_id`, `pat_amount`, `pay_status`) VALUES ('2', '55', '4', '2000', '1');
INSERT INTO `tbl_partialpay` (`pay_id`, `guest_id_fk`, `check_id`, `pat_amount`, `pay_status`) VALUES ('3', '58', '4', '1000', '1');


#
# TABLE STRUCTURE FOR: tbl_receiptdetails
#

DROP TABLE IF EXISTS `tbl_receiptdetails`;

CREATE TABLE `tbl_receiptdetails` (
  `receipt_id` int(20) NOT NULL AUTO_INCREMENT,
  `rec_id` int(20) NOT NULL,
  `account_head` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `narration` varchar(300) NOT NULL,
  `fin_year` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `created_date` date NOT NULL,
  `isactive` varchar(50) NOT NULL,
  `receipt_status` int(20) NOT NULL,
  PRIMARY KEY (`receipt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_receiptdetails` (`receipt_id`, `rec_id`, `account_head`, `amount`, `narration`, `fin_year`, `user_id`, `type`, `created_date`, `isactive`, `receipt_status`) VALUES ('1', '100', 'Laundry', '200', 'Payment for Laundry ', '2018-2019', '1', 'receipt', '2018-12-17', '0', '1');


#
# TABLE STRUCTURE FOR: tbl_receiptentry
#

DROP TABLE IF EXISTS `tbl_receiptentry`;

CREATE TABLE `tbl_receiptentry` (
  `entry_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `entry_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `receipt_head` int(11) NOT NULL,
  `receiptid` int(11) NOT NULL,
  `entry_amount` double NOT NULL,
  `paidto` varchar(50) NOT NULL,
  `entry_narration` text NOT NULL,
  `entry_status` int(11) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_receiptentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `receipt_head`, `receiptid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('1', '2018-2019', '2019-05-08', '1', '1', '100', '200', 'dfgfdh', ' fgfghjfgh', '1');


#
# TABLE STRUCTURE FOR: tbl_reservation
#

DROP TABLE IF EXISTS `tbl_reservation`;

CREATE TABLE `tbl_reservation` (
  `reserv_id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_id_fk` int(11) NOT NULL,
  `fin_year` varchar(20) NOT NULL,
  `created_date` date NOT NULL,
  `name` varchar(20) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `street` text NOT NULL,
  `city` text NOT NULL,
  `country` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `checkin_date` date NOT NULL,
  `checkout_date` date NOT NULL,
  `room` int(11) NOT NULL,
  `room_charge` double NOT NULL,
  `no_of_person` int(11) NOT NULL,
  `no_of_days` int(11) NOT NULL,
  `additional_charge` double NOT NULL,
  `discount` double NOT NULL,
  `subtotal` double NOT NULL,
  `paidamount` double NOT NULL,
  `balance_amount` double NOT NULL,
  `checkout_status` int(11) NOT NULL,
  `reserv_status` int(11) NOT NULL,
  PRIMARY KEY (`reserv_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_roomdetails
#

DROP TABLE IF EXISTS `tbl_roomdetails`;

CREATE TABLE `tbl_roomdetails` (
  `room_id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_name` int(11) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `room_ac` varchar(50) NOT NULL,
  `room_number` varchar(50) NOT NULL,
  `room_pic` text NOT NULL,
  `no_of_occ` int(11) NOT NULL,
  `add_of_occ` double NOT NULL,
  `room_rate` double NOT NULL,
  `room_features` text NOT NULL,
  `occupied` int(11) NOT NULL DEFAULT '0',
  `room_active` int(11) NOT NULL,
  `room_status` int(11) NOT NULL,
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('1', '1', '6', 'NonAC', 'A-101 (1)', 'a1.jpg', '2', '300', '1300', 'SIMPLE AND ELEGENT DOUBLE BED NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('2', '1', '6', 'NonAC', 'A-102 (2)', 'a2.jpg', '2', '300', '1300', 'SIMPLE AND ELEGENT DOUBLE BED NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('3', '1', '6', 'AC', 'A-103 (16)', 'a16.jpg', '2', '300', '900', 'SIMPLE AND ELEGENT DOUBLE BED A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('4', '1', '6', 'AC', 'A-104 (17)', 'a17.jpg', '2', '300', '900', 'SIMPLE AND ELEGENT DOUBLE BED  A/C ROOMS,SIDE TABLE,DRESSING CUBOARD WITH MIRROR AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV,TOWEL,SOAP,SHAMPOO AND DRINKING WATER,RATE:   CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('5', '2', '1', 'NonAC', '104', '20181204_121626.jpeg', '2', '200', '350', 'DORMITORIES,WITH FIVE TO SIX BEDS,HOT AND COLD WATER SHOWER.A CLEAN ENVIRONMENT.RATE:Rs350 PER BED.', '0', '0', '0');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('6', '2', '1', 'AC', '105', '20181204_122021.jpeg', '1', '200', '320', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.', '0', '0', '0');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('7', '1', '1', 'NonAC', '106', '20181204_122848.jpeg', '1', '200', '500', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.', '0', '0', '0');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('8', '2', '1', 'AC', '123', '20181204_121309.jpeg', '2', '100', '500', 'sdfdsfdsf dfgdfg dsfdsfdsfds', '0', '1', '0');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('9', '1', '1', 'AC', '807', '20181204_115711.jpeg', '2', '300', '600', 'cvbcvbcvb dfdsfsdfds', '1', '0', '0');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('10', '1', '1', 'AC', '3301', 'Not uploaded', '2', '300', '1000', '', '0', '2', '0');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('11', '1', '1', 'AC', '201', 'Not uploaded', '2', '300', '1300', 'dfsdfsdfsdffsdfsda', '0', '2', '0');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('12', '1', '6', 'NonAC', 'A-105 (12)', 'a12.jpg', '2', '300', '900', 'SIMPLE AND ELEGENT DOUBLE BED NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('13', '1', '6', 'NonAC', 'A-106 (14)', 'a14.jpg', '2', '300', '900', 'SIMPLE AND ELEGENT DOUBLE BED NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('14', '1', '6', 'NonAC', 'A-107 (15)', 'a15.jpg', '2', '300', '800', 'SIMPLE AND ELEGENT DOUBLE BED NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('15', '1', '6', 'NonAC', 'A-201 (3)', 'a31.jpg', '1', '300', '800', 'SIMPLE AND ELEGENT SINGLE BED NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '2', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('16', '1', '6', 'AC', 'A-202 (4)', 'a4.jpg', '2', '300', '2000', 'SIMPLE AND ELEGENT DOUBLE BED A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('17', '1', '6', 'NonAC', 'A-301 (7)', 'a7.jpg', '1', '300', '800', 'SIMPLE AND ELEGENT SINGLE  BED NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '2', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('18', '1', '6', 'NonAC', 'A-302 (6)', 'a6.jpg', '1', '300', '800', 'SIMPLE AND ELEGENT SINGLE BED NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('19', '1', '6', 'AC', 'A-303 (5)', 'a5.jpg', '2', '300', '1300', 'SIMPLE AND ELEGENT DOUBLE BED A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('20', '1', '6', 'AC', 'A-304 (8)', 'a8.jpg', '2', '300', '1800', 'SIMPLE AND ELEGENT THREE BED A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('21', '1', '6', 'AC', 'A-305 (9)', 'a9.jpg', '2', '300', '1800', 'SIMPLE AND ELEGENT THREE BED A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('22', '1', '6', 'NonAC', 'A-306 (10)', 'a10.jpg', '1', '300', '800', 'SIMPLE AND ELEGENT SINGLE BED NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('23', '1', '3', 'AC', 'A-307 (11)', '15490126058211432011420480196197.jpg', '12', '250', '2500', 'DORMITARY ROOMS UPTO 12 PAX WITH 2 TOILETS SIMPLE AND ELEGENT A/C & NON A/C ROOM, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('24', '1', '2', 'NonAC', 'B-108', 'Not uploaded', '2', '300', '1000', 'SIMPLE AND ELEGENT DOUBLE BED NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('25', '1', '2', 'NonAC', 'B-109', 'Not uploaded', '2', '300', '1000', 'SIMPLE AND ELEGENT DOUBLE BED NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '1', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('26', '1', '2', 'NonAC', 'B-110', 'Not uploaded', '2', '300', '1000', 'SIMPLE AND ELEGENT DOUBLE BED NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '1', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('27', '1', '2', 'NonAC', 'B-111', 'Not uploaded', '2', '300', '1000', 'SIMPLE AND ELEGENT DOUBLE BED NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('28', '1', '2', 'NonAC', 'B-112', 'Not uploaded', '2', '300', '1000', 'SIMPLE AND ELEGENT DOUBLE BED NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '1', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('29', '1', '2', 'NonAC', 'B-113', 'Not uploaded', '2', '300', '1000', 'SIMPLE AND ELEGENT DOUBLE BED NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('30', '1', '2', 'NonAC', 'B-114', 'Not uploaded', '2', '300', '1000', 'SIMPLE AND ELEGENT DOUBLE BED NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('31', '1', '2', 'AC', 'B-203', 'Not uploaded', '2', '300', '1500', 'SIMPLE AND ELEGENT DOUBLE BED A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('32', '1', '2', 'AC', 'B-204', 'Not uploaded', '2', '300', '2000', 'SIMPLE AND ELEGENT DOUBLE BED A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('33', '1', '2', 'AC', 'B-205', 'Not uploaded', '2', '300', '2000', 'SIMPLE AND ELEGENT DOUBLE BED A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('34', '1', '2', 'AC', 'B-206', 'Not uploaded', '2', '300', '1500', 'SIMPLE AND ELEGENT DOUBLE BED A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('35', '1', '2', 'AC', 'B-207', 'Not uploaded', '2', '300', '1500', 'SIMPLE AND ELEGENT DOUBLE BED A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('36', '1', '2', 'AC', 'B-208', 'Not uploaded', '2', '300', '1500', 'SIMPLE AND ELEGENT DOUBLE BED A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('37', '2', '2', 'AC', 'C-201', '7_c201.jpg', '2', '300', '2500', 'SIMPLE AND ELEGENT DOUBLE BED A/C & NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('38', '2', '2', 'AC', 'C-202', '8_c202.jpg', '2', '300', '2500', 'SIMPLE AND ELEGENT DOUBLE BED A/C & NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('39', '2', '2', 'AC', 'C-203', '9_c203.jpg', '2', '300', '2500', 'SIMPLE AND ELEGENT DOUBLE BED A/C & NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('40', '2', '2', 'AC', 'C-204', '10_c204.jpg', '2', '300', '2000', 'SIMPLE AND ELEGENT DOUBLE BED A/C & NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('41', '2', '2', 'AC', 'C-205', '11_c205.jpg', '2', '300', '2000', 'SIMPLE AND ELEGENT DOUBLE BED A/C & NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('42', '2', '2', 'AC', 'C-206', '12_c206.jpg', '2', '300', '2000', 'SIMPLE AND ELEGENT DOUBLE BED A/C & NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('43', '2', '2', 'AC', 'C-102', '1_c102.jpg', '2', '300', '2000', 'SIMPLE AND ELEGENT DOUBLE BED A/C & NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('44', '2', '2', 'AC', 'C-103', '2_c103.jpg', '2', '300', '2000', 'SIMPLE AND ELEGENT DOUBLE BED A/C & NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('45', '2', '2', 'AC', 'C-104', '3_c104.jpg', '2', '300', '2000', 'SIMPLE AND ELEGENT DOUBLE BED A/C & NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('46', '2', '2', 'AC', 'C-105', '4_c105.jpg', '2', '300', '2000', 'SIMPLE AND ELEGENT DOUBLE BED A/C & NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('47', '2', '2', 'AC', 'C-106', '5_c106.jpg', '2', '300', '2000', 'SIMPLE AND ELEGENT DOUBLE BED A/C & NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('48', '2', '2', 'AC', 'C-107', '6_c107.jpg', '2', '300', '2000', 'SIMPLE AND ELEGENT DOUBLE BED A/C & NON A/C ROOMS, SIDE TABLE, DRESSING CUBOARD WITH MIRROR, AND A CLEAN TOILET, BATH ROOM EQUIPPED WITH EUROPEAN CLOSET, WASH BASIN WITH MIRROR, HOT AND COLD SHOWER,LED TV, TOWEL, SOAP, SHAMPOO AND DRINKING WATER CLEAN AND WELL KEPT.', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('49', '2', '3', 'NonAC', 'C-301', '13_c301.jpg', '1', '250', '250', 'Dormitory Room / Big Room, Attached Toilets, Dining Facility etc', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('50', '2', '3', 'NonAC', 'C-302', '6_c_kitchen.jpg', '0', '0', '0', 'kitchen', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('51', '2', '3', 'NonAC', 'C-303', '14_c303__3041.jpg', '1', '250', '250', 'Dormitory Room / Big Room, Attached Toilets, Dining Facility etc', '0', '0', '1');
INSERT INTO `tbl_roomdetails` (`room_id`, `hotel_name`, `room_type`, `room_ac`, `room_number`, `room_pic`, `no_of_occ`, `add_of_occ`, `room_rate`, `room_features`, `occupied`, `room_active`, `room_status`) VALUES ('52', '2', '3', 'NonAC', 'C-304', '14_c303__304.jpg', '1', '250', '250', 'Dormitory Room / Big Room, Attached Toilets, Dining Facility etc', '0', '0', '1');


#
# TABLE STRUCTURE FOR: tbl_roommaster
#

DROP TABLE IF EXISTS `tbl_roommaster`;

CREATE TABLE `tbl_roommaster` (
  `masterid` int(11) NOT NULL AUTO_INCREMENT,
  `mastername` varchar(250) NOT NULL,
  `masterdescription` text NOT NULL,
  `masterstatus` int(11) NOT NULL,
  PRIMARY KEY (`masterid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_roommaster` (`masterid`, `mastername`, `masterdescription`, `masterstatus`) VALUES ('1', 'STANDARD ROOM', 'AC & Non AC Rooms, Television, Free Wifi, Card Payment, Power Backup, CCTV Cameras', '0');
INSERT INTO `tbl_roommaster` (`masterid`, `mastername`, `masterdescription`, `masterstatus`) VALUES ('2', 'DELUXE ROOMS', 'AC & Non AC Rooms, Television, Free Wifi, Card Payment, Power Backup, CCTV Cameras', '1');
INSERT INTO `tbl_roommaster` (`masterid`, `mastername`, `masterdescription`, `masterstatus`) VALUES ('3', 'Dormitory Rooms / Large Rooms', 'AC & Non AC Rooms, Television, Free Wifi, Card Payment, Power Backup, CCTV Cameras', '1');
INSERT INTO `tbl_roommaster` (`masterid`, `mastername`, `masterdescription`, `masterstatus`) VALUES ('4', 'wyteruywerih', 'dfgfdg dfgfgfdgfdg ', '0');
INSERT INTO `tbl_roommaster` (`masterid`, `mastername`, `masterdescription`, `masterstatus`) VALUES ('5', 'KITCHEN FACILITY - GROUPS', 'Providing Kitchen Facility for Groups.', '0');
INSERT INTO `tbl_roommaster` (`masterid`, `mastername`, `masterdescription`, `masterstatus`) VALUES ('6', 'STANDARD ROOM', 'AC & Non AC Rooms, Television, Free Wifi, Card Payment, Power Backup, CCTV Cameras', '1');


#
# TABLE STRUCTURE FOR: tbl_taxdetails
#

DROP TABLE IF EXISTS `tbl_taxdetails`;

CREATE TABLE `tbl_taxdetails` (
  `tax_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_name` varchar(50) NOT NULL,
  `tax_amount` double NOT NULL,
  `cgst` double NOT NULL,
  `sgst` double NOT NULL,
  `igst` double NOT NULL,
  `tax_status` int(11) NOT NULL,
  PRIMARY KEY (`tax_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_taxdetails` (`tax_id`, `tax_name`, `tax_amount`, `cgst`, `sgst`, `igst`, `tax_status`) VALUES ('1', 'GST 12%', '12', '6', '6', '12', '1');
INSERT INTO `tbl_taxdetails` (`tax_id`, `tax_name`, `tax_amount`, `cgst`, `sgst`, `igst`, `tax_status`) VALUES ('2', 'GST 18%', '18', '9', '9', '18', '1');
INSERT INTO `tbl_taxdetails` (`tax_id`, `tax_name`, `tax_amount`, `cgst`, `sgst`, `igst`, `tax_status`) VALUES ('3', 'Zero', '0', '0', '0', '0', '1');


#
# TABLE STRUCTURE FOR: tbl_voucherdetails
#

DROP TABLE IF EXISTS `tbl_voucherdetails`;

CREATE TABLE `tbl_voucherdetails` (
  `voucher_id` int(11) NOT NULL AUTO_INCREMENT,
  `vouch_id` int(11) NOT NULL,
  `account_head` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `narration` text NOT NULL,
  `created_date` date NOT NULL,
  `isactive` int(11) NOT NULL,
  `fin_year` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `voucher_status` int(11) NOT NULL,
  PRIMARY KEY (`voucher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('1', '100', 'LAUNDRY', '0', 'Payment given for Laundry  ', '2019-01-05', '0', '2018-2019', '1', 'voucher', '1');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('2', '101', 'ELECTRICITY - JI (Jumayira International)', '0', ' Payment to KSEB for JI', '2019-01-05', '0', '2018-2019', '1', 'voucher', '1');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('3', '102', 'ELECTRICITY - JR (Jumayira Residency)', '0', ' Payment to KSEB for JR', '2019-01-05', '0', '2018-2019', '1', 'voucher', '1');
INSERT INTO `tbl_voucherdetails` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('4', '103', 'LAUNDRY', '1500', '5-1-18 payment given ', '2019-01-05', '0', '2018-2019', '1', 'voucher', '1');


#
# TABLE STRUCTURE FOR: tbl_voucherentry
#

DROP TABLE IF EXISTS `tbl_voucherentry`;

CREATE TABLE `tbl_voucherentry` (
  `entry_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `entry_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `voucher_head` int(11) NOT NULL,
  `voucherid` int(11) NOT NULL,
  `entry_amount` double NOT NULL,
  `paidto` varchar(50) NOT NULL,
  `entry_narration` text NOT NULL,
  `entry_status` int(11) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_voucherentry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('1', '2018-2019', '2019-05-08', '1', '1', '100', '1000', 'fghg', ' fgfghgh', '1');


